import { db } from "@/db";
import { addresses, orders } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { desc, eq } from "drizzle-orm";
import { redirect } from "next/navigation";
import { AccountView } from "./account-view";

export async function AccountPageData({ section = "profile" }: { section?: string }) {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  const [addressRows, orderRows] = await Promise.all([
    db.select().from(addresses).where(eq(addresses.userId, user.id)).orderBy(desc(addresses.isDefault), desc(addresses.id)),
    db.select({ id: orders.id, orderNumber: orders.orderNumber, status: orders.status, paymentStatus: orders.paymentStatus, total: orders.total, placedAt: orders.placedAt, paymentMethod: orders.paymentMethod }).from(orders).where(eq(orders.userId, user.id)).orderBy(desc(orders.placedAt)),
  ]);
  return <AccountView user={user} initialAddresses={addressRows} orders={orderRows} section={section} />;
}
