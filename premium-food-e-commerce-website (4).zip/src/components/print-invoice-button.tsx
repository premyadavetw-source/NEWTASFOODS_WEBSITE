"use client";
import { Download, Printer } from "lucide-react";
export function PrintInvoiceButton() { return <button className="btn btn-outline print-invoice" onClick={() => window.print()}><Printer /><span>Print / Save invoice PDF</span><Download /></button>; }
