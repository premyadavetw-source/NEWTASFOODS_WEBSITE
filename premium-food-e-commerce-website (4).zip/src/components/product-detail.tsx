"use client";

import type { DemoProduct } from "@/lib/demo-data";
import { BadgeCheck, Check, ChevronRight, Heart, MapPin, Minus, Plus, Search, ShieldCheck, ShoppingBag, Star, Truck, X, ZoomIn } from "lucide-react";
import Image from "next/image";
import { useRouter } from "next/navigation";
import { useState, type FormEvent } from "react";
import { useCommerce } from "./commerce-provider";
import { money, ProductRow } from "./product-card";

export function ProductDetail({ product, together, similar, suggested }: { product: DemoProduct; together: DemoProduct[]; similar: DemoProduct[]; suggested: DemoProduct[] }) {
  const [selectedImage, setSelectedImage] = useState(product.images[0]);
  const [zoomed, setZoomed] = useState(false);
  const [variantId, setVariantId] = useState(product.variants[0]?.id);
  const [quantity, setQuantity] = useState(1);
  const [delivery, setDelivery] = useState<{ available: boolean; message: string; date?: string } | null>(null);
  const [checking, setChecking] = useState(false);
  const [tab, setTab] = useState("description");
  const { addToCart, toggleWishlist, isWishlisted } = useCommerce();
  const router = useRouter();
  const variant = product.variants.find((item) => item.id === variantId) ?? product.variants[0];
  const discount = Math.round((1 - variant.price / variant.mrp) * 100);

  async function checkPincode(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setChecking(true);
    const form = new FormData(event.currentTarget);
    const response = await fetch(`/api/delivery?pincode=${form.get("pincode")}`);
    const result = await response.json(); setChecking(false); setDelivery(result);
  }

  const tabs: Record<string, React.ReactNode> = {
    description: <><h3>Product description</h3><p>{product.description}</p><h3>Ingredients</h3><p>{product.ingredients}</p><h3>Storage instructions</h3><p>Store in a cool, dry place away from direct sunlight. Reseal after opening.</p></>,
    nutrition: <><h3>Nutritional information</h3><div className="nutrition-table">{Object.entries(product.nutrition).map(([label, value]) => <div key={label}><span>{label}</span><strong>{value}</strong></div>)}</div><p className="data-note">Sample placeholders must be replaced with verified pack information in admin before launch.</p></>,
    details: <><h3>Product details</h3><dl className="details-list"><div><dt>Net quantity</dt><dd>{variant.label}</dd></div><div><dt>SKU</dt><dd>{variant.sku}</dd></div><div><dt>Shelf life</dt><dd>Editable in admin</dd></div><div><dt>Country of origin</dt><dd>India</dd></div><div><dt>Manufacturer</dt><dd>NEWTAS FOODS AND AGRO PRIVATE LIMITED</dd></div><div><dt>FSSAI licence</dt><dd>To be updated with verified information</dd></div><div><dt>HSN</dt><dd>{product.hsn}</dd></div><div><dt>Allergen information</dt><dd>Check final pack label before use</dd></div></dl></>,
    reviews: <div className="reviews-empty"><BadgeCheck /><h3>No approved reviews yet</h3><p>Verified customer feedback will appear here after purchase and moderation.</p></div>,
  };

  return <>
    <section className="product-detail-grid shell">
      <div className="gallery"><div className="thumbs">{product.images.map((image, index) => <button className={selectedImage === image ? "active" : ""} key={`${image}-${index}`} onClick={() => setSelectedImage(image)}><Image src={image} alt={`${product.name} view ${index + 1}`} fill sizes="80px" /></button>)}</div><button className="main-product-image" onClick={() => setZoomed(true)}><Image src={selectedImage} alt={product.name} fill priority sizes="(max-width: 900px) 90vw, 45vw" /><span><ZoomIn /> Click to zoom</span></button></div>
      <div className="product-purchase">
        <p className="product-brand large">NEWTAS <span>• Sample catalog item</span></p>
        <h1>{product.name}</h1>
        <p className="product-long-subtitle">{product.shortDescription}</p>
        <div className="detail-rating"><span><Star fill="currentColor" /> {product.rating}</span><a href="#reviews">{product.reviewCount > 0 ? `${product.reviewCount} reviews` : "No reviews yet"}</a><small>SKU: {variant.sku}</small></div>
        <div className="detail-price"><strong>{money(variant.price)}</strong><s>MRP {money(variant.mrp)}</s><b>{discount}% OFF</b></div>
        <p className="tax-note">Inclusive of applicable GST • Unit price shown for {variant.label}</p>
        <div className="variant-block"><p>Choose pack size: <strong>{variant.label}</strong></p><div>{product.variants.map((item) => <button className={variantId === item.id ? "active" : ""} onClick={() => setVariantId(item.id)} key={item.id}><strong>{item.label}</strong><span>{money(item.price)}</span></button>)}</div></div>
        <div className="stock-detail"><Check /> <span><strong>{variant.stock > 0 ? "In stock" : "Currently unavailable"}</strong>{variant.stock > 0 && " — ready to dispatch after verification"}</span></div>
        <div className="purchase-actions"><div className="quantity-picker"><button onClick={() => setQuantity(Math.max(1, quantity - 1))} aria-label="Decrease quantity"><Minus /></button><span>{quantity}</span><button onClick={() => setQuantity(Math.min(20, quantity + 1))} aria-label="Increase quantity"><Plus /></button></div><button className="btn btn-primary add-large" onClick={() => addToCart(product, variant.id, quantity)}><ShoppingBag /> Add to cart</button><button className={`detail-wish ${isWishlisted(product.id) ? "active" : ""}`} onClick={() => toggleWishlist(product)} aria-label="Toggle wishlist"><Heart fill={isWishlisted(product.id) ? "currentColor" : "none"} /></button></div>
        <button className="btn buy-large" onClick={() => { addToCart(product, variant.id, quantity); router.push("/checkout"); }}>Buy now</button>
        <form className="pincode-check" onSubmit={checkPincode}><MapPin /><div><strong>Check delivery</strong><span>Enter your 6-digit pincode</span></div><input name="pincode" inputMode="numeric" pattern="[1-9][0-9]{5}" placeholder="Pincode" required /><button>{checking ? "..." : "Check"}</button></form>
        {delivery && <p className={`delivery-result ${delivery.available ? "success" : "error"}`}>{delivery.available ? <Truck /> : <X />}{delivery.message}{delivery.date && <strong>{delivery.date}</strong>}</p>}
        <div className="purchase-trust"><span><ShieldCheck /> Secure checkout</span><span><Truck /> Trackable delivery</span><span><BadgeCheck /> GST invoice</span></div>
      </div>
    </section>

    <section className="product-info-section shell"><div className="info-tabs" role="tablist">{[["description", "Description"], ["nutrition", "Nutrition"], ["details", "Product details"], ["reviews", "Reviews"]].map(([key, label]) => <button role="tab" aria-selected={tab === key} className={tab === key ? "active" : ""} onClick={() => setTab(key)} key={key}>{label}</button>)}</div><div className="info-panel" id="reviews">{tabs[tab]}</div></section>

    <section className="product-faq shell"><p className="eyebrow">Questions about this product</p><h2>Frequently asked</h2><details open><summary>Is this product information final?<Plus /></summary><p>No. This is clearly marked demonstration data. Verified ingredients, nutrition, allergens, FSSAI, shelf life and manufacturer details must be approved in admin before launch.</p></details><details><summary>How should I choose a pack size?<Plus /></summary><p>Select the required pack above. Price, MRP, SKU and live stock update with each variant.</p></details><details><summary>Can I get a GST invoice?<Plus /></summary><p>Yes. The order architecture stores GST, HSN, customer and company details for a printable invoice.</p></details></section>

    <section className="section shell recommendation-section"><div className="section-heading"><div><p>Complete your pantry</p><h2>Frequently bought together</h2></div></div><ProductRow products={together} /></section>
    <section className="section shell recommendation-section"><div className="section-heading"><div><p>More in {product.categoryName}</p><h2>Similar products</h2></div></div><ProductRow products={similar} /></section>
    <section className="section shell recommendation-section"><div className="section-heading"><div><p>Explore more</p><h2>You may also like</h2></div></div><ProductRow products={suggested} /></section>

    {zoomed && <div className="zoom-modal" onClick={() => setZoomed(false)}><button aria-label="Close image zoom"><X /></button><div onClick={(event) => event.stopPropagation()}><Image src={selectedImage} alt={`${product.name} enlarged`} fill sizes="90vw" /></div></div>}
  </>;
}
