"use client";

import { Heart, ShoppingBag, Trash2 } from "lucide-react";
import Image from "next/image";
import Link from "next/link";
import { useCommerce } from "./commerce-provider";
import { money } from "./product-card";

export function WishlistView() {
  const { wishlist, toggleWishlist, addToCart } = useCommerce();
  if (!wishlist.length) return <div className="account-empty shell"><Heart /><h1>Your wishlist is waiting.</h1><p>Save products you love and move them to your cart whenever you’re ready.</p><Link href="/shop" className="btn btn-primary">Discover products</Link></div>;
  return <main><nav className="breadcrumb shell"><Link href="/">Home</Link><span>›</span><strong>Wishlist</strong></nav><section className="section shell"><div className="account-page-title"><div><p>Saved for later</p><h1>My wishlist</h1></div><span>{wishlist.length} products</span></div><div className="wishlist-grid">{wishlist.map((product) => <article key={product.id}><Link className="wishlist-image" href={`/${product.category}/${product.slug}`}><Image src={product.image} alt={product.name} fill sizes="180px" /></Link><div><p>NEWTAS</p><Link href={`/${product.category}/${product.slug}`}><h2>{product.name}</h2></Link><span className="price-change">Price at time of viewing</span><strong>{money(product.price)}</strong><small className={product.stock ? "in" : "out"}>{product.stock ? "In stock" : "Out of stock"}</small><button className="btn btn-primary" disabled={!product.stock} onClick={() => { addToCart(product); toggleWishlist(product); }}><ShoppingBag /> Move to cart</button><button className="wishlist-remove" onClick={() => toggleWishlist(product)}><Trash2 /> Remove</button></div></article>)}</div></section></main>;
}
