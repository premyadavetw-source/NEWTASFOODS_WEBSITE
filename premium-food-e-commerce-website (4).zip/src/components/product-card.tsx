"use client";

import type { DemoProduct } from "@/lib/demo-data";
import { Heart, ShoppingBag, Star } from "lucide-react";
import Image from "next/image";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { useCommerce } from "./commerce-provider";

export function money(value: number) {
  return new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(value);
}

export function ProductCard({ product, compact = false }: { product: DemoProduct; compact?: boolean }) {
  const { addToCart, toggleWishlist, isWishlisted } = useCommerce();
  const [variantId, setVariantId] = useState(product.variants[0]?.id);
  const [added, setAdded] = useState(false);
  const router = useRouter();
  const variant = product.variants.find((item) => item.id === variantId) ?? product.variants[0];
  const discount = variant?.mrp ? Math.round((1 - variant.price / variant.mrp) * 100) : 0;
  const wished = isWishlisted(product.id);

  function add() {
    addToCart(product, variant?.id);
    setAdded(true);
    window.setTimeout(() => setAdded(false), 1300);
  }

  return (
    <article className={`product-card ${compact ? "compact" : ""}`}>
      <div className="product-image-wrap">
        {product.bestSeller && <span className="product-badge">Bestseller</span>}
        {product.isNew && !product.bestSeller && <span className="product-badge new">New</span>}
        <button className={`wish-button ${wished ? "active" : ""}`} aria-label={wished ? "Remove from wishlist" : "Add to wishlist"} onClick={() => toggleWishlist(product)}><Heart fill={wished ? "currentColor" : "none"} /></button>
        <Link href={`/${product.category}/${product.slug}`}><Image src={product.image} alt={`${product.name} sample product presentation`} fill sizes="(max-width: 640px) 45vw, (max-width: 1024px) 30vw, 230px" /></Link>
      </div>
      <div className="product-info">
        <p className="product-brand">NEWTAS <span>• Sample catalog</span></p>
        <Link href={`/${product.category}/${product.slug}`}><h3>{product.name}</h3></Link>
        {!compact && <p className="product-desc">{product.shortDescription}</p>}
        <div className="rating-line"><span><Star size={12} fill="currentColor" /> {product.rating}</span><small>{product.reviewCount > 0 ? `${product.reviewCount} reviews` : "New product"}</small></div>
        <select className="pack-select" value={variantId} onChange={(event) => setVariantId(Number(event.target.value))} aria-label={`Pack size for ${product.name}`}>
          {product.variants.map((item) => <option key={item.id} value={item.id}>{item.label} — {money(item.price)}</option>)}
        </select>
        <div className="price-line"><strong>{money(variant?.price ?? product.price)}</strong><s>{money(variant?.mrp ?? product.mrp)}</s>{discount > 0 && <span>{discount}% off</span>}</div>
        <p className={`stock-line ${(variant?.stock ?? product.stock) < 1 ? "out" : ""}`}>{(variant?.stock ?? product.stock) > 0 ? "In stock" : "Out of stock"}</p>
        <div className="product-actions">
          <button className="btn btn-cart" disabled={(variant?.stock ?? 0) < 1} onClick={add}><ShoppingBag size={17} /> {added ? "Added" : "Add"}</button>
          <button className="btn btn-buy" disabled={(variant?.stock ?? 0) < 1} onClick={() => { addToCart(product, variant?.id); router.push("/checkout"); }}>Buy now</button>
        </div>
      </div>
    </article>
  );
}

export function ProductRow({ products }: { products: DemoProduct[] }) {
  return <div className="product-row">{products.map((product) => <ProductCard product={product} key={product.id} />)}</div>;
}
