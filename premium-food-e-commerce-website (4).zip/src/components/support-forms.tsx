"use client";

import { CheckCircle2, LoaderCircle, PackageSearch, Send } from "lucide-react";
import { useState, type FormEvent } from "react";

export function ContactForm() {
  const [status, setStatus] = useState("");
  const [loading, setLoading] = useState(false);
  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setLoading(true); setStatus("");
    const form = new FormData(event.currentTarget);
    const response = await fetch("/api/contact", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(Object.fromEntries(form.entries())) });
    setLoading(false);
    setStatus(response.ok ? "Thank you. Your message has been recorded for the NEWTAS team." : "Please check all details and try again.");
    if (response.ok) event.currentTarget.reset();
  }
  return <form className="contact-form" onSubmit={submit}><div className="field-row"><label>Full name<input name="name" required minLength={2} placeholder="Your name" /></label><label>Mobile number<input name="mobile" required pattern="[0-9]{10}" placeholder="10-digit mobile" /></label></div><label>Email address<input name="email" type="email" required placeholder="you@example.com" /></label><label>How can we help?<select name="subject"><option>Product enquiry</option><option>Order support</option><option>Business enquiry</option><option>Feedback</option></select></label><label>Message<textarea name="message" required minLength={10} rows={5} placeholder="Please share the details..." /></label><button className="btn btn-primary" disabled={loading}>{loading ? <LoaderCircle className="spin" /> : <Send />} Send message</button>{status && <p className="form-status"><CheckCircle2 />{status}</p>}</form>;
}

export function TrackOrderForm() {
  const [order, setOrder] = useState<Record<string, string> | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setLoading(true); setError(""); setOrder(null);
    const form = new FormData(event.currentTarget);
    const params = new URLSearchParams({ order: String(form.get("order")), mobile: String(form.get("mobile")) });
    const response = await fetch(`/api/orders/track?${params}`);
    const result = await response.json(); setLoading(false);
    if (response.ok) setOrder(result.order); else setError(result.message ?? "We could not find that order.");
  }
  const steps = ["placed", "confirmed", "packed", "shipped", "out_for_delivery", "delivered"];
  const activeIndex = order ? steps.indexOf(order.status) : -1;
  return <div className="track-card"><form onSubmit={submit}><label>Order ID<input name="order" required placeholder="e.g. NWT-2026-00001" /></label><label>Registered mobile<input name="mobile" required pattern="[0-9]{10}" placeholder="10-digit mobile number" /></label><button className="btn btn-primary" disabled={loading}><PackageSearch />{loading ? "Checking..." : "Track order"}</button></form>{error && <p className="form-error">{error}</p>}{order && <div className="tracking-result"><p>Order <strong>{order.orderNumber}</strong></p><div className="tracking-steps">{steps.map((step, index) => <div className={index <= activeIndex ? "complete" : ""} key={step}><span>{index < activeIndex ? "✓" : index + 1}</span><small>{step.replaceAll("_", " ")}</small></div>)}</div></div>}<div className="track-help"><strong>Where is my Order ID?</strong><p>Find it in your order confirmation or under My Orders after signing in.</p></div></div>;
}
