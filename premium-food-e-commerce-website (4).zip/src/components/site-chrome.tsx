"use client";
import { usePathname } from "next/navigation";
import type { ReactNode } from "react";
import { SiteFooter } from "./site-footer";
import { SiteHeader } from "./site-header";
export function SiteChrome({ children }: { children: ReactNode }) {
  const pathname = usePathname();
  const standalone = pathname.startsWith("/admin") || pathname === "/login" || pathname === "/register";
  if (standalone) return children;
  return <><SiteHeader />{children}<SiteFooter /></>;
}
