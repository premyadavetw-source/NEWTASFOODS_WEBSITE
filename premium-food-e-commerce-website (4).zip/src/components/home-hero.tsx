"use client";

import { heroImages } from "@/lib/demo-data";
import { ArrowRight, ChevronLeft, ChevronRight, Sparkles } from "lucide-react";
import Image from "next/image";
import Link from "next/link";
import { useEffect, useState } from "react";

const slides = [
  { eyebrow: "The NEWTAS pantry", title: "Pure Ingredients. Better Living.", copy: "Premium dry fruits, dates, seeds, spices and everyday grocery—selected with care.", image: heroImages.main, href: "/shop", tone: "green" },
  { eyebrow: "Naturally rewarding", title: "Goodness in every date.", copy: "Discover naturally sweet Zahidi and Medjool dates in convenient pack sizes.", image: heroImages.dates, href: "/dates", tone: "brown" },
  { eyebrow: "Everyday Indian kitchens", title: "Aroma you can trust.", copy: "Pure spices and balanced blends, hygienically packed for memorable meals.", image: heroImages.spices, href: "/spices-masala", tone: "spice" },
];

export function HomeHero() {
  const [active, setActive] = useState(0);
  useEffect(() => {
    const timer = window.setInterval(() => setActive((current) => (current + 1) % slides.length), 6500);
    return () => window.clearInterval(timer);
  }, []);
  const slide = slides[active];
  return (
    <section className={`home-hero hero-${slide.tone}`}>
      <Image src={slide.image} alt="Premium NEWTAS food collection" fill priority sizes="100vw" />
      <div className="hero-shade" />
      <div className="shell hero-content">
        <p><Sparkles size={16} /> {slide.eyebrow}</p>
        <h1>{slide.title}</h1>
        <h2>{slide.copy}</h2>
        <div className="hero-actions"><Link className="btn btn-primary" href={slide.href}>Shop now <ArrowRight size={18} /></Link><Link className="btn btn-ghost-light" href="/shop">Explore products</Link></div>
      </div>
      <button className="hero-arrow prev" onClick={() => setActive((active - 1 + slides.length) % slides.length)} aria-label="Previous promotion"><ChevronLeft /></button>
      <button className="hero-arrow next" onClick={() => setActive((active + 1) % slides.length)} aria-label="Next promotion"><ChevronRight /></button>
      <div className="hero-dots">{slides.map((item, index) => <button key={item.title} className={index === active ? "active" : ""} onClick={() => setActive(index)} aria-label={`Show promotion ${index + 1}`} />)}</div>
    </section>
  );
}
