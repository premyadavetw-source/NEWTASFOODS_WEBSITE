"use client";

import { Check, ChevronLeft, CreditCard, Landmark, LoaderCircle, LockKeyhole, MapPin, PackageCheck, Plus, QrCode, ShieldCheck, Smartphone, Truck, Wallet } from "lucide-react";
import Image from "next/image";
import Link from "next/link";
import { useEffect, useState, type FormEvent } from "react";
import { useCommerce } from "./commerce-provider";
import { money } from "./product-card";

type Address = { id?: number; fullName: string; mobile: string; email?: string; house: string; street: string; area: string; city: string; state: string; pincode: string; landmark: string; isDefault?: boolean };
const emptyAddress: Address = { fullName: "", mobile: "", email: "", house: "", street: "", area: "", city: "", state: "Uttar Pradesh", pincode: "", landmark: "" };

export function CheckoutView() {
  const { cart, subtotal, savings, coupon, clearCart } = useCommerce();
  const active = cart.filter((line) => !line.savedForLater);
  const [step, setStep] = useState(1);
  const [address, setAddress] = useState<Address>(emptyAddress);
  const [saved, setSaved] = useState<Address[]>([]);
  const [signedIn, setSignedIn] = useState(false);
  const [payment, setPayment] = useState("cod");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [completed, setCompleted] = useState<{ orderNumber: string; total: number } | null>(null);
  const delivery = subtotal > 0 && subtotal < 499 ? 49 : 0;
  const discount = coupon?.discount ?? 0;
  const total = Math.max(0, subtotal - discount + delivery);
  const checkoutSteps = [{ number: 1, label: "Address" }, { number: 2, label: "Order summary" }, { number: 3, label: "Payment" }];
  const paymentOptions = [
    { value: "upi", title: "UPI", subtitle: "Google Pay, PhonePe, BHIM", Icon: QrCode, ready: false },
    { value: "card", title: "Credit / Debit Card", subtitle: "Visa, Mastercard, RuPay", Icon: CreditCard, ready: false },
    { value: "netbanking", title: "Net Banking", subtitle: "All major Indian banks", Icon: Landmark, ready: false },
    { value: "wallet", title: "Wallets", subtitle: "Provider-supported wallets", Icon: Wallet, ready: false },
    { value: "cod", title: "Cash on Delivery", subtitle: "Pay when your eligible order arrives", Icon: Truck, ready: true },
  ];

  useEffect(() => {
    fetch("/api/auth/me").then((response) => { if (!response.ok) throw new Error(); setSignedIn(true); return fetch("/api/addresses"); }).then((response) => response.json()).then((result) => { setSaved(result.addresses ?? []); const selected = result.addresses?.find((item: Address) => item.isDefault) ?? result.addresses?.[0]; if (selected) setAddress({ ...emptyAddress, ...selected }); }).catch(() => undefined);
  }, []);

  function setField(field: keyof Address, value: string) { setAddress((current) => ({ ...current, [field]: value })); }
  function validateAddress(event: FormEvent) { event.preventDefault(); if (!/^[6-9]\d{9}$/.test(address.mobile) || !/^[1-9]\d{5}$/.test(address.pincode) || !address.fullName || !address.house || !address.area || !address.city || !address.state) return setError("Please complete all required address fields."); setError(""); setStep(2); window.scrollTo({ top: 0, behavior: "smooth" }); }
  async function placeOrder() {
    setLoading(true); setError("");
    const response = await fetch("/api/orders", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ address, items: active.map((line) => ({ variantId: line.variantId, quantity: line.quantity })), couponCode: coupon?.code || undefined, paymentMethod: payment }) });
    const result = await response.json(); setLoading(false);
    if (!response.ok) return setError(result.message ?? "Unable to place order.");
    if (result.order) { setCompleted(result.order); clearCart(); window.scrollTo({ top: 0, behavior: "smooth" }); }
  }

  if (completed) return <main className="checkout-success shell"><div className="success-check"><Check /></div><p>ORDER PLACED</p><h1>Thank you for choosing NEWTAS.</h1><span>Your Cash on Delivery order has been recorded successfully.</span><div className="success-order"><div><small>Order ID</small><strong>{completed.orderNumber}</strong></div><div><small>Payable amount</small><strong>{money(completed.total)}</strong></div><div><small>Payment</small><strong>Cash on Delivery</strong></div></div><div className="success-timeline"><span className="active"><i><Check /></i><b>Order placed</b></span><em /><span><i>2</i><b>Confirmation</b></span><em /><span><i>3</i><b>Dispatch</b></span></div><p className="success-note">Final courier serviceability and delivery date will be confirmed when the order is processed.</p><div><Link className="btn btn-primary" href="/account/orders">View my orders</Link><Link className="btn btn-outline" href="/shop">Continue shopping</Link></div></main>;

  if (!active.length) return <main className="account-empty shell"><PackageCheck /><h1>No items to check out.</h1><p>Add products to your cart before proceeding.</p><Link href="/shop" className="btn btn-primary">Shop products</Link></main>;

  return <main className="checkout-bg"><nav className="checkout-top shell"><Link href="/cart"><ChevronLeft /> Back to cart</Link><div><ShieldCheck /> Secure checkout</div></nav><section className="checkout-shell shell"><div className="checkout-main"><div className="checkout-steps">{checkoutSteps.map(({ number, label }) => <div className={step >= number ? "active" : ""} key={number}><span>{step > number ? <Check /> : number}</span><b>{label}</b>{number !== 3 && <i />}</div>)}</div>
    {step === 1 && <form className="checkout-card address-form" onSubmit={validateAddress}><div className="checkout-card-head"><div><p>STEP 1</p><h1>Delivery address</h1></div>{!signedIn && <Link href="/login">Sign in for saved addresses</Link>}</div>{saved.length > 0 && <div className="saved-address-select"><p>Choose a saved address</p>{saved.map((item) => <button type="button" className={address.id === item.id ? "active" : ""} key={item.id} onClick={() => setAddress({ ...emptyAddress, ...item })}><span>{item.isDefault ? "DEFAULT" : "SAVED"}</span><strong>{item.fullName}</strong><small>{item.house}, {item.area}, {item.city} — {item.pincode}</small>{address.id === item.id && <Check />}</button>)}<button type="button" className="new-address" onClick={() => setAddress(emptyAddress)}><Plus /> Use a new address</button></div>}<div className="field-row"><label>Full name *<input required value={address.fullName} onChange={(event) => setField("fullName", event.target.value)} /></label><label>Mobile number *<input required inputMode="numeric" pattern="[6-9][0-9]{9}" value={address.mobile} onChange={(event) => setField("mobile", event.target.value)} /></label></div><label>Email for order updates<input type="email" value={address.email ?? ""} onChange={(event) => setField("email", event.target.value)} /></label><label>House / Flat / Building *<input required value={address.house} onChange={(event) => setField("house", event.target.value)} /></label><label>Street / Road<input value={address.street} onChange={(event) => setField("street", event.target.value)} /></label><label>Area / Locality *<input required value={address.area} onChange={(event) => setField("area", event.target.value)} /></label><div className="field-row"><label>City *<input required value={address.city} onChange={(event) => setField("city", event.target.value)} /></label><label>State *<input required value={address.state} onChange={(event) => setField("state", event.target.value)} /></label></div><div className="field-row"><label>Pincode *<input required inputMode="numeric" pattern="[1-9][0-9]{5}" value={address.pincode} onChange={(event) => setField("pincode", event.target.value)} /></label><label>Landmark<input value={address.landmark} onChange={(event) => setField("landmark", event.target.value)} /></label></div>{error && <p className="form-error">{error}</p>}<button className="btn btn-primary checkout-next">Continue to order summary</button></form>}
    {step === 2 && <div className="checkout-card"><div className="checkout-card-head"><div><p>STEP 2</p><h1>Review your order</h1></div><button onClick={() => setStep(1)}>Edit address</button></div><div className="checkout-address-summary"><MapPin /><span><strong>Deliver to {address.fullName}</strong><p>{address.house}, {address.street && `${address.street}, `}{address.area}, {address.city}, {address.state} — {address.pincode}</p><small>+91 {address.mobile}</small></span></div><div className="checkout-items">{active.map((line) => { const variant = line.product.variants.find((item) => item.id === line.variantId) ?? line.product.variants[0]; return <div key={line.variantId}><Image src={line.product.image} alt={line.product.name} width={80} height={80} /><span><small>NEWTAS</small><strong>{line.product.name}</strong><p>{variant.label} × {line.quantity}</p></span><b>{money(variant.price * line.quantity)}</b></div>; })}</div><div className="checkout-delivery-note"><Truck /><span><strong>Indicative delivery in 3–7 business days</strong><small>Final date after courier serviceability confirmation.</small></span></div><button className="btn btn-primary checkout-next" onClick={() => { setStep(3); window.scrollTo({ top: 0, behavior: "smooth" }); }}>Continue to payment</button></div>}
    {step === 3 && <div className="checkout-card"><div className="checkout-card-head"><div><p>STEP 3</p><h1>Choose payment</h1></div><button onClick={() => setStep(2)}>Review order</button></div><div className="payment-security"><LockKeyhole /><span><strong>Payment credentials stay with the gateway.</strong><small>NEWTAS never stores card or UPI credentials.</small></span></div><div className="payment-options">{paymentOptions.map(({ value, title, subtitle, Icon, ready }) => <label className={payment === value ? "active" : ""} key={value}><input type="radio" name="payment" value={value} checked={payment === value} onChange={() => setPayment(value)} /><span className="payment-icon"><Icon /></span><span><strong>{title}</strong><small>{subtitle}</small></span>{ready ? <b>AVAILABLE</b> : <em>GATEWAY REQUIRED</em>}</label>)}</div>{payment !== "cod" && <div className="gateway-notice"><Smartphone /><span><strong>Online gateway setup required</strong><small>No payment will be attempted until verified provider credentials and an official adapter are enabled.</small></span></div>}{error && <p className="form-error">{error}</p>}<button className="btn btn-primary checkout-next" onClick={placeOrder} disabled={loading}>{loading ? <><LoaderCircle className="spin" /> Processing securely...</> : payment === "cod" ? `Place order • ${money(total)}` : `Continue securely • ${money(total)}`}</button><p className="terms-line">By placing the order you agree to the <Link href="/terms-conditions">Terms</Link> and <Link href="/return-refund-policy">Return Policy</Link>.</p></div>}
  </div><aside className="checkout-summary"><h2>Order summary</h2><span>{active.reduce((sum, line) => sum + line.quantity, 0)} items</span><div>{active.slice(0, 3).map((line) => <Image key={line.variantId} src={line.product.image} alt="" width={52} height={52} />)}</div><dl><div><dt>Product total</dt><dd>{money(subtotal)}</dd></div><div><dt>Product savings</dt><dd className="green">− {money(savings)}</dd></div>{discount > 0 && <div><dt>Coupon saving</dt><dd className="green">− {money(discount)}</dd></div>}<div><dt>Delivery</dt><dd>{delivery ? money(delivery) : <b className="green">FREE</b>}</dd></div><div><dt>Taxes</dt><dd>Included</dd></div></dl><p><span>Total payable</span><strong>{money(total)}</strong></p><small><ShieldCheck /> Secure • GST invoice • Trackable</small></aside></section></main>;
}
