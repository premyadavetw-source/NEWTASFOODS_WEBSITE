import { company } from "@/lib/demo-data";
import { Camera, Mail, MapPin, MessageCircle, Phone, Play, ShieldCheck } from "lucide-react";
import Link from "next/link";

const groups = [
  { title: "NEWTAS", links: [["About Us", "/about-us"], ["Contact", "/contact-us"], ["Careers", "/contact-us"]] },
  { title: "Shop", links: [["Dry Fruits", "/dry-fruits"], ["Dates", "/dates"], ["Seeds", "/seeds"], ["Spices & Masala", "/spices-masala"], ["Grocery", "/grocery"]] },
  { title: "Customer Support", links: [["Contact Us", "/contact-us"], ["FAQ", "/faq"], ["Shipping", "/shipping-policy"], ["Returns & Refunds", "/return-refund-policy"], ["Track Order", "/track-order"]] },
  { title: "Legal", links: [["Privacy Policy", "/privacy-policy"], ["Terms & Conditions", "/terms-conditions"], ["Cookie Policy", "/cookie-policy"]] },
];

export function SiteFooter() {
  return (
    <footer className="site-footer">
      <div className="footer-trust shell">
        <div><ShieldCheck /><span><strong>Secure shopping</strong><small>Payment-ready architecture</small></span></div>
        <div><span className="footer-icon">₹</span><span><strong>GST registered</strong><small>GSTIN: {company.gstin}</small></span></div>
        <div><span className="footer-icon">↻</span><span><strong>Customer support</strong><small>Order issue assistance</small></span></div>
      </div>
      <div className="footer-grid shell">
        {groups.map((group) => <div key={group.title}><h3>{group.title}</h3>{group.links.map(([label, href]) => <Link href={href} key={label}>{label}</Link>)}</div>)}
        <div className="footer-contact">
          <h3>Connect</h3>
          <a href={`mailto:${company.email}`}><Mail /> {company.email}</a>
          <a href={`tel:+91${company.directors[0].phone}`}><Phone /> +91 {company.directors[0].phone}</a>
          <p><MapPin /> {company.address}</p>
          <div className="socials"><a href="#" aria-label="Instagram"><Camera /></a><a href="#" aria-label="Facebook"><MessageCircle /></a><a href="#" aria-label="YouTube"><Play /></a></div>
        </div>
      </div>
      <div className="footer-bottom shell">
        <p>© {new Date().getFullYear()} {company.name}. All rights reserved.</p>
        <div className="payment-badges"><span>UPI</span><span>RuPay</span><span>VISA</span><span>Mastercard</span><span>COD</span></div>
      </div>
    </footer>
  );
}
