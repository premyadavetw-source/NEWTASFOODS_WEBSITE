"use client";

import { useCommerce } from "./commerce-provider";
import { ChevronDown, Heart, MapPin, Menu, PackageSearch, Search, ShoppingBag, UserRound, X } from "lucide-react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useState, type FormEvent } from "react";

const nav = [
  ["Home", "/"],
  ["Dry Fruits", "/dry-fruits"],
  ["Dates", "/dates"],
  ["Seeds", "/seeds"],
  ["Spices & Masala", "/spices-masala"],
  ["Grocery", "/grocery"],
  ["Offers", "/offers"],
];

const popular = ["California Almonds", "Medjool Dates", "Chia Seeds", "Turmeric Powder", "Poha"];

function BrandMark() {
  return (
    <span className="brand-lockup">
      <span className="brand-emblem" aria-hidden="true"><span>N</span></span>
      <span className="brand-word"><strong>NEWTAS</strong><small>FOODS & AGRO</small></span>
    </span>
  );
}

export function SiteHeader() {
  const { cartCount, wishlistCount } = useCommerce();
  const [menuOpen, setMenuOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [focused, setFocused] = useState(false);
  const router = useRouter();

  useEffect(() => {
    const close = () => setMenuOpen(false);
    window.addEventListener("resize", close);
    return () => window.removeEventListener("resize", close);
  }, []);

  function submit(event: FormEvent) {
    event.preventDefault();
    const clean = query.trim();
    if (clean) router.push(`/search?q=${encodeURIComponent(clean)}`);
  }

  const suggestions = popular.filter((item) => !query || item.toLowerCase().includes(query.toLowerCase()));

  return (
    <>
      <header className="site-header">
        <div className="announcement"><span>Pan-India delivery architecture ready</span><span>Secure checkout</span><span>Carefully selected ingredients</span></div>
        <div className="header-main shell">
          <button className="icon-button mobile-only" aria-label="Open menu" onClick={() => setMenuOpen(true)}><Menu size={22} /></button>
          <Link href="/" className="logo-link" aria-label="NEWTAS home"><BrandMark /></Link>
          <form className="search-box desktop-search" onSubmit={submit} role="search">
            <Search size={20} />
            <input value={query} onChange={(event) => setQuery(event.target.value)} onFocus={() => setFocused(true)} onBlur={() => window.setTimeout(() => setFocused(false), 150)} placeholder="Search almonds, dates, masala, grocery..." aria-label="Search products" />
            <button type="submit">Search</button>
            {focused && <div className="search-suggestions">
              <p>{query ? "Suggested products" : "Popular searches"}</p>
              {suggestions.slice(0, 5).map((item) => <button type="button" key={item} onClick={() => { setQuery(item); router.push(`/search?q=${encodeURIComponent(item)}`); }}><Search size={15} />{item}</button>)}
            </div>}
          </form>
          <div className="header-actions">
            <Link href="/account" className="header-action"><UserRound /><span><small>Hello, sign in</small><strong>My Account</strong></span><ChevronDown size={14} className="desktop-only" /></Link>
            <Link href="/track-order" className="header-action desktop-only"><PackageSearch /><span><small>Track</small><strong>My Order</strong></span></Link>
            <Link href="/wishlist" className="header-action desktop-only count-wrap"><Heart /><span><small>Saved</small><strong>Wishlist</strong></span>{wishlistCount > 0 && <b>{wishlistCount}</b>}</Link>
            <Link href="/cart" className="header-action count-wrap"><ShoppingBag /><span className="desktop-only"><small>Your cart</small><strong>Cart</strong></span>{cartCount > 0 && <b>{cartCount}</b>}</Link>
          </div>
        </div>
        <form className="search-box mobile-search shell" onSubmit={submit} role="search"><Search size={18} /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search NEWTAS products" aria-label="Search products" /><button type="submit">Go</button></form>
        <nav className="category-nav desktop-only"><div className="shell">{nav.map(([label, href]) => <Link key={href} href={href}>{label}</Link>)}<Link href="/shop" className="all-products"><Menu size={15} /> All Products</Link><span className="nav-delivery"><MapPin size={14} /> Delivering across India</span></div></nav>
      </header>

      {menuOpen && <div className="drawer-backdrop" onClick={() => setMenuOpen(false)}>
        <aside className="mobile-drawer" onClick={(event) => event.stopPropagation()}>
          <div className="drawer-head"><BrandMark /><button className="icon-button" onClick={() => setMenuOpen(false)} aria-label="Close menu"><X /></button></div>
          <Link href="/login" className="drawer-account" onClick={() => setMenuOpen(false)}><UserRound /><span><strong>Welcome to NEWTAS</strong><small>Login or create an account</small></span></Link>
          <p className="drawer-label">Shop by category</p>
          {nav.map(([label, href]) => <Link key={href} href={href} onClick={() => setMenuOpen(false)}>{label}<span>›</span></Link>)}
          <div className="drawer-links"><Link href="/account/orders">My Orders</Link><Link href="/wishlist">Wishlist</Link><Link href="/contact-us">Help & Support</Link></div>
        </aside>
      </div>}

      <nav className="mobile-bottom-nav mobile-only" aria-label="Mobile navigation">
        <Link href="/"><span className="home-glyph">⌂</span><small>Home</small></Link>
        <button onClick={() => setMenuOpen(true)}><Menu /><small>Categories</small></button>
        <Link href="/search"><Search /><small>Search</small></Link>
        <Link href="/account/orders"><PackageSearch /><small>Orders</small></Link>
        <Link href="/cart" className="count-wrap"><ShoppingBag /><small>Cart</small>{cartCount > 0 && <b>{cartCount}</b>}</Link>
      </nav>
    </>
  );
}
