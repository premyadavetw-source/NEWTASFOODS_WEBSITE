"use client";

import type { DemoProduct } from "@/lib/demo-data";
import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";

type CartLine = {
  product: DemoProduct;
  variantId: number;
  quantity: number;
  savedForLater?: boolean;
};

type CouponState = { code: string; discount: number; message: string } | null;

type CommerceContextValue = {
  cart: CartLine[];
  wishlist: DemoProduct[];
  cartCount: number;
  wishlistCount: number;
  subtotal: number;
  savings: number;
  coupon: CouponState;
  addToCart: (product: DemoProduct, variantId?: number, quantity?: number) => void;
  removeFromCart: (variantId: number) => void;
  setQuantity: (variantId: number, quantity: number) => void;
  changeVariant: (oldVariantId: number, newVariantId: number) => void;
  toggleSaveForLater: (variantId: number) => void;
  toggleWishlist: (product: DemoProduct) => void;
  isWishlisted: (productId: number) => boolean;
  applyCoupon: (code: string) => Promise<CouponState>;
  clearCart: () => void;
};

const CommerceContext = createContext<CommerceContextValue | null>(null);

function readStorage<T>(key: string, fallback: T): T {
  if (typeof window === "undefined") return fallback;
  try {
    const value = window.localStorage.getItem(key);
    return value ? (JSON.parse(value) as T) : fallback;
  } catch {
    return fallback;
  }
}

function getGuestToken() {
  let token = window.localStorage.getItem("newtas-guest-token");
  if (!token) {
    token = crypto.randomUUID();
    window.localStorage.setItem("newtas-guest-token", token);
  }
  return token;
}

export function CommerceProvider({ children }: { children: ReactNode }) {
  const [cart, setCart] = useState<CartLine[]>([]);
  const [wishlist, setWishlist] = useState<DemoProduct[]>([]);
  const [coupon, setCoupon] = useState<CouponState>(null);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    setCart(readStorage("newtas-cart", []));
    setWishlist(readStorage("newtas-wishlist", []));
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    window.localStorage.setItem("newtas-cart", JSON.stringify(cart));
    const timer = window.setTimeout(() => {
      fetch("/api/cart", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          guestToken: getGuestToken(),
          items: cart.map((line) => ({ variantId: line.variantId, quantity: line.quantity, savedForLater: !!line.savedForLater })),
        }),
      }).catch(() => undefined);
    }, 350);
    return () => window.clearTimeout(timer);
  }, [cart, hydrated]);

  useEffect(() => {
    if (!hydrated) return;
    window.localStorage.setItem("newtas-wishlist", JSON.stringify(wishlist));
  }, [wishlist, hydrated]);

  const addToCart = useCallback((product: DemoProduct, variantId = product.variants[0]?.id, quantity = 1) => {
    if (!variantId) return;
    setCart((current) => {
      const existing = current.find((line) => line.variantId === variantId);
      if (existing) return current.map((line) => line.variantId === variantId ? { ...line, quantity: Math.min(20, line.quantity + quantity), savedForLater: false } : line);
      return [...current, { product, variantId, quantity: Math.max(1, quantity) }];
    });
  }, []);

  const removeFromCart = useCallback((variantId: number) => setCart((current) => current.filter((line) => line.variantId !== variantId)), []);
  const setQuantity = useCallback((variantId: number, quantity: number) => {
    if (quantity < 1) return removeFromCart(variantId);
    setCart((current) => current.map((line) => line.variantId === variantId ? { ...line, quantity: Math.min(20, quantity) } : line));
  }, [removeFromCart]);

  const changeVariant = useCallback((oldVariantId: number, newVariantId: number) => {
    setCart((current) => {
      const target = current.find((line) => line.variantId === oldVariantId);
      if (!target || oldVariantId === newVariantId) return current;
      const withoutOld = current.filter((line) => line.variantId !== oldVariantId);
      const existing = withoutOld.find((line) => line.variantId === newVariantId);
      if (existing) return withoutOld.map((line) => line.variantId === newVariantId ? { ...line, quantity: Math.min(20, line.quantity + target.quantity) } : line);
      return [...withoutOld, { ...target, variantId: newVariantId }];
    });
  }, []);

  const toggleSaveForLater = useCallback((variantId: number) => setCart((current) => current.map((line) => line.variantId === variantId ? { ...line, savedForLater: !line.savedForLater } : line)), []);

  const toggleWishlist = useCallback((product: DemoProduct) => {
    setWishlist((current) => current.some((item) => item.id === product.id) ? current.filter((item) => item.id !== product.id) : [...current, product]);
  }, []);

  const isWishlisted = useCallback((productId: number) => wishlist.some((item) => item.id === productId), [wishlist]);

  const activeCart = cart.filter((line) => !line.savedForLater);
  const subtotal = activeCart.reduce((sum, line) => {
    const variant = line.product.variants.find((item) => item.id === line.variantId) ?? line.product.variants[0];
    return sum + (variant?.price ?? line.product.price) * line.quantity;
  }, 0);
  const savings = activeCart.reduce((sum, line) => {
    const variant = line.product.variants.find((item) => item.id === line.variantId) ?? line.product.variants[0];
    return sum + ((variant?.mrp ?? line.product.mrp) - (variant?.price ?? line.product.price)) * line.quantity;
  }, 0);

  const applyCoupon = useCallback(async (code: string) => {
    try {
      const response = await fetch("/api/coupons/validate", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ code, subtotal }) });
      const result = await response.json();
      const next = result.valid ? { code: result.code, discount: result.discount, message: result.message } : { code: "", discount: 0, message: result.message ?? "Coupon is not valid." };
      setCoupon(next);
      return next;
    } catch {
      const next = { code: "", discount: 0, message: "Could not validate the coupon. Please try again." };
      setCoupon(next);
      return next;
    }
  }, [subtotal]);

  const value = useMemo<CommerceContextValue>(() => ({
    cart,
    wishlist,
    cartCount: activeCart.reduce((sum, line) => sum + line.quantity, 0),
    wishlistCount: wishlist.length,
    subtotal,
    savings,
    coupon,
    addToCart,
    removeFromCart,
    setQuantity,
    changeVariant,
    toggleSaveForLater,
    toggleWishlist,
    isWishlisted,
    applyCoupon,
    clearCart: () => setCart([]),
  }), [cart, wishlist, activeCart, subtotal, savings, coupon, addToCart, removeFromCart, setQuantity, changeVariant, toggleSaveForLater, toggleWishlist, isWishlisted, applyCoupon]);

  return <CommerceContext.Provider value={value}>{children}</CommerceContext.Provider>;
}

export function useCommerce() {
  const context = useContext(CommerceContext);
  if (!context) throw new Error("useCommerce must be used inside CommerceProvider");
  return context;
}
