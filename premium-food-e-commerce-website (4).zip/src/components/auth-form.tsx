"use client";

import { ArrowRight, Check, Eye, EyeOff, LockKeyhole, Mail, ShieldCheck, ShoppingBag, Smartphone, UserRound } from "lucide-react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState, type FormEvent } from "react";

export function AuthForm({ mode }: { mode: "login" | "register" }) {
  const [show, setShow] = useState(false);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");
  const router = useRouter();
  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setLoading(true); setMessage("");
    const data = Object.fromEntries(new FormData(event.currentTarget).entries());
    const response = await fetch(`/api/auth/${mode}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data) });
    const result = await response.json(); setLoading(false);
    if (!response.ok) return setMessage(result.message ?? "Please try again.");
    router.push("/account"); router.refresh();
  }
  return <main className="auth-page"><section className="auth-benefits"><div><Link href="/" className="auth-logo"><span>N</span><b>NEWTAS</b></Link><p>PREMIUM PANTRY • SECURE SHOPPING</p><h1>{mode === "login" ? "Welcome back to better choices." : "Your pantry, thoughtfully organized."}</h1><span>Sign in to manage orders, addresses, wishlists and a faster checkout.</span><ul><li><Check /> Track every order in one place</li><li><Check /> Save addresses securely</li><li><Check /> Keep favourites close</li><li><Check /> Access eligible offers</li></ul><div className="auth-trust"><ShieldCheck /><span><strong>Privacy-first account security</strong><small>Hashed passwords and server-side sessions</small></span></div></div></section><section className="auth-form-side"><div className="auth-card"><div className="auth-card-icon">{mode === "login" ? <LockKeyhole /> : <UserRound />}</div><p>{mode === "login" ? "CUSTOMER LOGIN" : "CREATE ACCOUNT"}</p><h2>{mode === "login" ? "Sign in to NEWTAS" : "Join NEWTAS"}</h2><span>{mode === "login" ? "Enter your registered details to continue." : "A few details and you’re ready to shop."}</span><form onSubmit={submit}>{mode === "register" && <label><span>Full name</span><div><UserRound /><input name="name" required minLength={2} placeholder="Your full name" /></div></label>}{mode === "register" && <label><span>Mobile number</span><div><Smartphone /><input name="mobile" required pattern="[6-9][0-9]{9}" inputMode="numeric" placeholder="10-digit mobile number" /></div></label>}<label><span>{mode === "login" ? "Email or mobile" : "Email address"}</span><div><Mail /><input name={mode === "login" ? "identity" : "email"} required type={mode === "register" ? "email" : "text"} placeholder={mode === "login" ? "Email or mobile number" : "you@example.com"} /></div></label><label><span>Password</span><div><LockKeyhole /><input name="password" required minLength={8} maxLength={72} type={show ? "text" : "password"} placeholder="Minimum 8 characters" /><button type="button" onClick={() => setShow(!show)} aria-label="Toggle password visibility">{show ? <EyeOff /> : <Eye />}</button></div></label>{mode === "login" && <div className="auth-options"><label><input type="checkbox" /> Keep me signed in</label><a href="mailto:newtasfoodsandagro@gmail.com?subject=Password reset help">Forgot password?</a></div>}{message && <p className="auth-error">{message}</p>}<button className="btn btn-primary auth-submit" disabled={loading}>{loading ? "Please wait..." : mode === "login" ? "Sign in securely" : "Create my account"}<ArrowRight /></button></form><div className="auth-switch">{mode === "login" ? <>New to NEWTAS? <Link href="/register">Create an account</Link></> : <>Already have an account? <Link href="/login">Sign in</Link></>}</div><Link href="/shop" className="guest-link"><ShoppingBag /> Continue shopping as guest</Link></div></section></main>;
}
