"use client";

import { Bell, ChevronRight, CircleUserRound, Heart, Home, LogOut, MapPin, Package, Pencil, Plus, Save, Tag, Trash2, X } from "lucide-react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState, type FormEvent } from "react";
import { money } from "./product-card";

type AccountUser = { id: number; name: string; email: string; mobile: string; role: "customer" | "admin" };
type Address = { id: number; fullName: string; mobile: string; house: string; street: string | null; area: string; city: string; state: string; pincode: string; landmark: string | null; isDefault: boolean };
type OrderRow = { id: number; orderNumber: string; status: string; paymentStatus: string; total: string; placedAt: Date; paymentMethod: string };

const nav = [
  ["profile", "Profile", CircleUserRound], ["addresses", "Addresses", MapPin], ["orders", "My Orders", Package], ["wishlist", "Wishlist", Heart], ["coupons", "Coupons", Tag], ["notifications", "Notifications", Bell],
] as const;

export function AccountView({ user, initialAddresses, orders, section }: { user: AccountUser; initialAddresses: Address[]; orders: OrderRow[]; section: string }) {
  const [addressList, setAddressList] = useState(initialAddresses);
  const [editing, setEditing] = useState<Address | "new" | null>(null);
  const [message, setMessage] = useState("");
  const router = useRouter();
  const active = nav.some(([key]) => key === section) ? section : "profile";

  async function saveAddress(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setMessage("");
    const values = Object.fromEntries(new FormData(event.currentTarget).entries());
    const payload = { ...values, id: editing !== "new" && editing ? editing.id : undefined, isDefault: values.isDefault === "on" };
    const response = await fetch("/api/addresses", { method: editing === "new" ? "POST" : "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
    const result = await response.json();
    if (!response.ok) return setMessage(result.message);
    setAddressList((current) => editing === "new" ? [...current.map((item) => payload.isDefault ? { ...item, isDefault: false } : item), result.address] : current.map((item) => item.id === result.address.id ? result.address : payload.isDefault ? { ...item, isDefault: false } : item));
    setEditing(null);
  }
  async function deleteAddress(id: number) {
    const response = await fetch("/api/addresses", { method: "DELETE", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id }) });
    if (response.ok) setAddressList((current) => current.filter((item) => item.id !== id));
  }
  async function logout() { await fetch("/api/auth/logout", { method: "POST" }); router.push("/"); router.refresh(); }

  return <main className="account-bg"><nav className="breadcrumb shell"><Link href="/">Home</Link><span>›</span><strong>My Account</strong></nav><section className="account-shell shell"><aside className="account-sidebar"><div className="account-person"><span>{user.name.charAt(0).toUpperCase()}</span><div><small>Welcome back</small><strong>{user.name}</strong></div></div><nav>{nav.map(([key, label, Icon]) => <Link className={active === key ? "active" : ""} href={`/account/${key}`} key={key}><Icon />{label}<ChevronRight /></Link>)}{user.role === "admin" && <Link href="/admin"><Home />Admin dashboard<ChevronRight /></Link>}<button onClick={logout}><LogOut />Logout</button></nav></aside><div className="account-content">
    {active === "profile" && <><div className="account-content-title"><div><p>Personal information</p><h1>My profile</h1></div></div><div className="profile-card"><div className="profile-avatar">{user.name.charAt(0).toUpperCase()}</div><div><span>Full name</span><strong>{user.name}</strong></div><div><span>Email address</span><strong>{user.email}</strong></div><div><span>Mobile number</span><strong>+91 {user.mobile}</strong></div><p>For account detail changes, contact NEWTAS support to protect your account.</p></div><div className="account-quick-grid"><Link href="/account/orders"><Package /><span><strong>{orders.length} orders</strong><small>View order history</small></span><ChevronRight /></Link><Link href="/wishlist"><Heart /><span><strong>Saved products</strong><small>Open your wishlist</small></span><ChevronRight /></Link><Link href="/account/addresses"><MapPin /><span><strong>{addressList.length} addresses</strong><small>Manage delivery addresses</small></span><ChevronRight /></Link></div></>}
    {active === "addresses" && <><div className="account-content-title"><div><p>Delivery details</p><h1>Saved addresses</h1></div><button className="btn btn-primary" onClick={() => setEditing("new")}><Plus /> Add address</button></div>{addressList.length ? <div className="address-grid">{addressList.map((address) => <article key={address.id}>{address.isDefault && <span className="default-badge">Default</span>}<h2>{address.fullName}</h2><p>{address.house}{address.street && `, ${address.street}`}<br />{address.area}, {address.city}<br />{address.state} — {address.pincode}</p>{address.landmark && <small>Landmark: {address.landmark}</small>}<strong>+91 {address.mobile}</strong><div><button onClick={() => setEditing(address)}><Pencil /> Edit</button><button onClick={() => deleteAddress(address.id)}><Trash2 /> Delete</button></div></article>)}</div> : <div className="account-inline-empty"><MapPin /><h2>No saved address</h2><p>Add an address for a faster checkout.</p><button className="btn btn-outline" onClick={() => setEditing("new")}><Plus /> Add your first address</button></div>}</>}
    {active === "orders" && <><div className="account-content-title"><div><p>Purchase history</p><h1>My orders</h1></div></div>{orders.length ? <div className="orders-list">{orders.map((order) => <article key={order.id}><div><small>ORDER ID</small><strong>{order.orderNumber}</strong></div><div><small>PLACED ON</small><strong>{new Date(order.placedAt).toLocaleDateString("en-IN")}</strong></div><div><small>TOTAL</small><strong>{money(Number(order.total))}</strong></div><span className={`order-status ${order.status}`}>{order.status.replaceAll("_", " ")}</span><Link href={`/orders/${order.orderNumber}`}>View details <ChevronRight /></Link></article>)}</div> : <div className="account-inline-empty"><Package /><h2>No orders yet</h2><p>Your order history will appear here.</p><Link className="btn btn-primary" href="/shop">Start shopping</Link></div>}</>}
    {active === "wishlist" && <div className="account-inline-empty"><Heart /><h1>Your saved products</h1><p>Wishlist products are stored securely in this browser and can be moved to cart.</p><Link href="/wishlist" className="btn btn-primary">Open wishlist</Link></div>}
    {active === "coupons" && <><div className="account-content-title"><div><p>Available savings</p><h1>My coupons</h1></div></div><div className="account-coupons">{[["NEW100", "₹100 off above ₹999"], ["FIRSTORDER", "10% off above ₹499, up to ₹150"], ["WELCOME10", "10% off above ₹599, up to ₹100"]].map(([code, terms]) => <div key={code}><Tag /><span><strong>{code}</strong><small>{terms}</small></span><button onClick={() => navigator.clipboard.writeText(code)}>Copy</button></div>)}</div><p className="data-note">Demo offers. Eligibility and expiry are validated by the server.</p></>}
    {active === "notifications" && <div className="account-inline-empty"><Bell /><h1>You’re all caught up</h1><p>Order updates and account notifications will appear here.</p></div>}
  </div></section>{editing && <div className="modal-backdrop"><form className="address-modal" onSubmit={saveAddress}><div className="modal-head"><div><p>DELIVERY ADDRESS</p><h2>{editing === "new" ? "Add a new address" : "Edit address"}</h2></div><button type="button" onClick={() => setEditing(null)}><X /></button></div><div className="field-row"><label>Full name<input name="fullName" required defaultValue={editing === "new" ? user.name : editing.fullName} /></label><label>Mobile<input name="mobile" required pattern="[6-9][0-9]{9}" defaultValue={editing === "new" ? user.mobile : editing.mobile} /></label></div><label>House / Flat / Building<input name="house" required defaultValue={editing === "new" ? "" : editing.house} /></label><label>Street / Road<input name="street" defaultValue={editing === "new" ? "" : editing.street ?? ""} /></label><label>Area / Locality<input name="area" required defaultValue={editing === "new" ? "" : editing.area} /></label><div className="field-row"><label>City<input name="city" required defaultValue={editing === "new" ? "" : editing.city} /></label><label>State<input name="state" required defaultValue={editing === "new" ? "Uttar Pradesh" : editing.state} /></label></div><div className="field-row"><label>Pincode<input name="pincode" required pattern="[1-9][0-9]{5}" defaultValue={editing === "new" ? "" : editing.pincode} /></label><label>Landmark<input name="landmark" defaultValue={editing === "new" ? "" : editing.landmark ?? ""} /></label></div><label className="checkbox-label"><input type="checkbox" name="isDefault" defaultChecked={editing === "new" ? !addressList.length : editing.isDefault} /> Make this my default address</label>{message && <p className="form-error">{message}</p>}<button className="btn btn-primary"><Save /> Save address</button></form></div>}</main>;
}
