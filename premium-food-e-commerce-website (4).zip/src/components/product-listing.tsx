"use client";

import type { DemoProduct } from "@/lib/demo-data";
import { ChevronDown, Filter, Search, SlidersHorizontal, X } from "lucide-react";
import { useMemo, useState } from "react";
import { ProductCard } from "./product-card";

type Sort = "popular" | "newest" | "price-low" | "price-high" | "rating" | "discount";

export function ProductListing({ products, category }: { products: DemoProduct[]; category?: string }) {
  const [sort, setSort] = useState<Sort>("popular");
  const [query, setQuery] = useState("");
  const [maxPrice, setMaxPrice] = useState(3000);
  const [rating, setRating] = useState(0);
  const [packs, setPacks] = useState<string[]>([]);
  const [onlyStock, setOnlyStock] = useState(false);
  const [onlyOffers, setOnlyOffers] = useState(false);
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [visible, setVisible] = useState(12);
  const [filtersOpen, setFiltersOpen] = useState(false);

  const availablePacks = Array.from(new Set(products.flatMap((product) => product.variants.map((variant) => variant.label))));
  const availableCategories = Array.from(new Map(products.map((product) => [product.category, product.categoryName])).entries());
  const activeFilterCount = packs.length + selectedCategories.length + Number(rating > 0) + Number(onlyStock) + Number(onlyOffers) + Number(maxPrice < 3000);

  const filtered = useMemo(() => {
    const result = products.filter((product) => {
      const matchesQuery = !query || `${product.name} ${product.shortDescription}`.toLowerCase().includes(query.toLowerCase());
      const matchesPrice = product.price <= maxPrice;
      const matchesRating = product.rating >= rating;
      const matchesPack = !packs.length || product.variants.some((variant) => packs.includes(variant.label));
      const matchesStock = !onlyStock || product.stock > 0;
      const matchesOffer = !onlyOffers || product.price < product.mrp;
      const matchesCategory = !selectedCategories.length || selectedCategories.includes(product.category);
      return matchesQuery && matchesPrice && matchesRating && matchesPack && matchesStock && matchesOffer && matchesCategory;
    });
    result.sort((a, b) => {
      if (sort === "price-low") return a.price - b.price;
      if (sort === "price-high") return b.price - a.price;
      if (sort === "rating") return b.rating - a.rating;
      if (sort === "newest") return Number(b.isNew) - Number(a.isNew) || b.id - a.id;
      if (sort === "discount") return (1 - b.price / b.mrp) - (1 - a.price / a.mrp);
      return Number(b.bestSeller) - Number(a.bestSeller) || b.rating - a.rating;
    });
    return result;
  }, [products, query, maxPrice, rating, packs, onlyStock, onlyOffers, selectedCategories, sort]);

  function toggle<T>(value: T, current: T[], setter: (next: T[]) => void) {
    setter(current.includes(value) ? current.filter((item) => item !== value) : [...current, value]);
    setVisible(12);
  }

  function reset() {
    setQuery(""); setMaxPrice(3000); setRating(0); setPacks([]); setOnlyStock(false); setOnlyOffers(false); setSelectedCategories([]); setVisible(12);
  }

  const Filters = () => <>
    <div className="filter-title"><div><SlidersHorizontal size={19} /><strong>Filters</strong>{activeFilterCount > 0 && <span>{activeFilterCount}</span>}</div><button onClick={reset}>Clear all</button></div>
    {!category && <div className="filter-group"><h3>Category <ChevronDown /></h3>{availableCategories.map(([slug, name]) => <label key={slug}><input type="checkbox" checked={selectedCategories.includes(slug)} onChange={() => toggle(slug, selectedCategories, setSelectedCategories)} /><span>{name}</span></label>)}</div>}
    <div className="filter-group"><h3>Price <ChevronDown /></h3><div className="range-label"><span>₹0</span><strong>Up to ₹{maxPrice}</strong></div><input className="range-input" type="range" min="100" max="3000" step="100" value={maxPrice} onChange={(event) => setMaxPrice(Number(event.target.value))} /></div>
    <div className="filter-group"><h3>Pack size <ChevronDown /></h3><div className="pack-filters">{availablePacks.map((pack) => <button className={packs.includes(pack) ? "active" : ""} key={pack} onClick={() => toggle(pack, packs, setPacks)}>{pack}</button>)}</div></div>
    <div className="filter-group"><h3>Customer rating <ChevronDown /></h3>{[4, 3].map((value) => <label key={value}><input type="radio" name="rating" checked={rating === value} onChange={() => setRating(value)} /><span><b>★</b> {value}.0 & above</span></label>)}</div>
    <div className="filter-group"><h3>Availability & offers <ChevronDown /></h3><label><input type="checkbox" checked={onlyStock} onChange={(event) => setOnlyStock(event.target.checked)} /><span>In stock only</span></label><label><input type="checkbox" checked={onlyOffers} onChange={(event) => setOnlyOffers(event.target.checked)} /><span>Discounted products</span></label></div>
  </>;

  return (
    <div className="listing-layout">
      <aside className="filter-sidebar desktop-only"><Filters /></aside>
      <div className="listing-main">
        <div className="listing-toolbar">
          <div className="within-search"><Search size={17} /><input value={query} onChange={(event) => { setQuery(event.target.value); setVisible(12); }} placeholder="Search within this collection" /></div>
          <button className="filter-mobile mobile-only" onClick={() => setFiltersOpen(true)}><Filter /> Filters {activeFilterCount > 0 && <span>{activeFilterCount}</span>}</button>
          <label className="sort-select"><span>Sort by:</span><select value={sort} onChange={(event) => setSort(event.target.value as Sort)}><option value="popular">Popularity</option><option value="newest">Newest</option><option value="price-low">Price: Low to High</option><option value="price-high">Price: High to Low</option><option value="rating">Customer Rating</option><option value="discount">Discount</option></select></label>
        </div>
        <p className="results-count"><strong>{filtered.length}</strong> products found</p>
        {filtered.length ? <div className="product-grid">{filtered.slice(0, visible).map((product) => <ProductCard product={product} key={product.id} />)}</div> : <div className="empty-state"><Search /><h2>No products found</h2><p>Try changing a filter or search term.</p><button className="btn btn-outline" onClick={reset}>Reset filters</button></div>}
        {visible < filtered.length && <div className="load-more"><button className="btn btn-outline" onClick={() => setVisible((count) => count + 12)}>Load more products</button><span>Showing {Math.min(visible, filtered.length)} of {filtered.length}</span></div>}
      </div>
      {filtersOpen && <div className="filter-drawer-backdrop" onClick={() => setFiltersOpen(false)}><aside className="filter-drawer" onClick={(event) => event.stopPropagation()}><div className="filter-drawer-head"><strong>Filter products</strong><button onClick={() => setFiltersOpen(false)}><X /></button></div><Filters /><button className="btn btn-primary apply-filter" onClick={() => setFiltersOpen(false)}>Show {filtered.length} products</button></aside></div>}
    </div>
  );
}
