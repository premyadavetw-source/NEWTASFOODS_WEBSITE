"use client";

import { ArrowRight, CheckCircle2 } from "lucide-react";
import { useState, type FormEvent } from "react";

export function NewsletterForm() {
  const [email, setEmail] = useState("");
  const [status, setStatus] = useState("");
  async function submit(event: FormEvent) {
    event.preventDefault();
    const response = await fetch("/api/newsletter", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ email }) });
    setStatus(response.ok ? "You’re on the list. Welcome to NEWTAS." : "Please enter a valid email address.");
    if (response.ok) setEmail("");
  }
  return <form className="newsletter-form" onSubmit={submit}><div><input type="email" value={email} onChange={(event) => setEmail(event.target.value)} placeholder="Enter your email address" required aria-label="Email address" /><button className="btn" type="submit">Subscribe <ArrowRight size={17} /></button></div>{status && <p><CheckCircle2 size={15} />{status}</p>}</form>;
}
