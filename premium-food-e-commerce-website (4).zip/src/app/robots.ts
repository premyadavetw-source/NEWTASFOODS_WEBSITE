import type { MetadataRoute } from "next";
export default function robots(): MetadataRoute.Robots {
  const base = process.env.NEXT_PUBLIC_SITE_URL ?? "https://newtasfoods.com";
  return { rules: { userAgent: "*", allow: "/", disallow: ["/admin", "/account", "/checkout", "/cart", "/wishlist", "/api", "/orders"] }, sitemap: `${base}/sitemap.xml`, host: base };
}
