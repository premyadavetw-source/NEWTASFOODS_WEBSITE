import type { MetadataRoute } from "next";
import { getCatalog } from "@/lib/catalog";
import { demoCategories, policyContent } from "@/lib/demo-data";

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const base = process.env.NEXT_PUBLIC_SITE_URL ?? "https://newtasfoods.com";
  const products = await getCatalog();
  const staticPaths = ["", "/shop", "/offers", "/about-us", "/contact-us", "/faq", ...demoCategories.map((item) => `/${item.slug}`), ...Object.keys(policyContent).map((item) => `/${item}`)];
  return [
    ...staticPaths.map((path) => ({ url: `${base}${path}`, lastModified: new Date(), changeFrequency: path === "" ? "daily" as const : "weekly" as const, priority: path === "" ? 1 : .7 })),
    ...products.map((product) => ({ url: `${base}/${product.category}/${product.slug}`, lastModified: new Date(), changeFrequency: "weekly" as const, priority: .8 })),
  ];
}
