import { AccountPageData } from "@/components/account-page-data";
import type { Metadata } from "next";
export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "My Account", robots: { index: false, follow: false } };
export default function AccountPage() { return <AccountPageData />; }
