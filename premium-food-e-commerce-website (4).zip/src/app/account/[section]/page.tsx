import { AccountPageData } from "@/components/account-page-data";
import type { Metadata } from "next";
export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "My Account", robots: { index: false, follow: false } };
type Props = { params: Promise<{ section: string }> };
export default async function AccountSectionPage({ params }: Props) { const { section } = await params; return <AccountPageData section={section} />; }
