import { HomeHero } from "@/components/home-hero";
import { NewsletterForm } from "@/components/newsletter-form";
import { ProductRow } from "@/components/product-card";
import { getCatalog } from "@/lib/catalog";
import { demoCategories } from "@/lib/demo-data";
import { ArrowRight, BadgeCheck, Headphones, PackageCheck, ShieldCheck, Sparkles, Truck } from "lucide-react";
import Image from "next/image";
import Link from "next/link";

export const dynamic = "force-dynamic";

const benefits = [
  { icon: BadgeCheck, title: "Quality-focused", body: "Products selected with clear quality and catalog controls." },
  { icon: PackageCheck, title: "Hygienic packaging", body: "Packaging details and batches managed through inventory." },
  { icon: Sparkles, title: "Carefully selected", body: "A considered range for everyday Indian households." },
  { icon: ShieldCheck, title: "Secure payments", body: "Gateway-ready checkout keeps credentials server-side." },
  { icon: Truck, title: "Delivery ready", body: "Pincode, courier and tracking integration architecture." },
  { icon: Headphones, title: "Real support", body: "Direct assistance from the NEWTAS team when you need it." },
];

export default async function HomePage() {
  const products = await getCatalog();
  const bestSellers = products.filter((product) => product.bestSeller).slice(0, 5);
  const newArrivals = products.filter((product) => product.isNew).slice(0, 5);
  const featured = products.filter((product) => product.featured).slice(0, 5);

  return (
    <main>
      <HomeHero />

      <section className="section shell">
        <div className="section-heading"><div><p>Curated pantry</p><h2>Shop by category</h2><span>Thoughtfully organized for faster everyday shopping.</span></div><Link href="/shop">View all products <ArrowRight size={16} /></Link></div>
        <div className="category-grid">
          {demoCategories.map((category, index) => <Link href={`/${category.slug}`} className={`category-card category-${index + 1}`} key={category.slug}>
            <Image src={category.image} alt={category.name} fill sizes="(max-width: 700px) 90vw, 33vw" />
            <div className="category-overlay"><span>0{index + 1}</span><h3>{category.name}</h3><p>{category.description}</p><strong>Shop now <ArrowRight size={15} /></strong></div>
          </Link>)}
        </div>
      </section>

      <section className="section products-section shell">
        <div className="section-heading"><div><p>Customer favourites</p><h2>Best sellers</h2><span>Popular picks from the NEWTAS sample collection.</span></div><Link href="/shop?sort=popular">Shop best sellers <ArrowRight size={16} /></Link></div>
        <ProductRow products={bestSellers} />
      </section>

      <section className="offer-banner shell">
        <div><p>WELCOME OFFER</p><h2>Make room for better pantry choices.</h2><span>Use <strong>WELCOME10</strong> for 10% off above ₹599, up to ₹100. Demo offer terms apply.</span><Link href="/offers" className="btn">Explore all offers <ArrowRight size={17} /></Link></div>
        <div className="offer-orbit"><span>10<small>%</small></span><p>OFF</p></div>
      </section>

      <section className="section shell">
        <div className="section-heading"><div><p>Freshly added</p><h2>New arrivals</h2><span>Discover new pantry additions across our growing range.</span></div><Link href="/shop?sort=newest">See what’s new <ArrowRight size={16} /></Link></div>
        <ProductRow products={newArrivals} />
      </section>

      <section className="editorial-banner shell">
        <div className="editorial-copy"><p>Inside every NEWTAS pack</p><h2>Selected with purpose.<br />Packed with care.</h2><span>Our catalog and inventory workflow is built for traceability—from SKU and batch details to stock alerts and product information.</span><Link href="/about-us">Our company <ArrowRight size={17} /></Link></div>
        <div className="editorial-stats"><div><strong>5</strong><span>Pantry categories</span></div><div><strong>100%</strong><span>Editable product data</span></div><div><strong>0</strong><span>Invented claims</span></div></div>
      </section>

      <section className="section shell">
        <div className="section-heading"><div><p>Premium selection</p><h2>Featured products</h2><span>Products highlighted by the store team.</span></div><Link href="/shop">Explore the full pantry <ArrowRight size={16} /></Link></div>
        <ProductRow products={featured} />
      </section>

      <section className="why-section">
        <div className="shell"><div className="section-heading light"><div><p>The NEWTAS promise</p><h2>Built for trust, not noise.</h2><span>A clear, professional shopping experience with product information at the centre.</span></div></div>
          <div className="benefit-grid">{benefits.map(({ icon: Icon, title, body }) => <div key={title}><Icon /><h3>{title}</h3><p>{body}</p></div>)}</div>
        </div>
      </section>

      <section className="section shell review-section">
        <div className="section-heading"><div><p>Customer reviews</p><h2>Verified voices, once published.</h2><span>We do not invent testimonials. Approved reviews from genuine purchasers will appear here after launch.</span></div><Link href="/faq">How reviews work <ArrowRight size={16} /></Link></div>
        <div className="review-empty"><span>“</span><div><h3>No published reviews yet</h3><p>Be among the first to share an honest experience after purchasing a NEWTAS product.</p></div><BadgeCheck /></div>
      </section>

      <section className="newsletter"><div className="shell"><div><p>Stay close to the pantry</p><h2>Subscribe to NEWTAS updates.</h2><span>New products, practical offers and company updates—sent thoughtfully.</span></div><NewsletterForm /></div></section>
    </main>
  );
}
