import { PrintInvoiceButton } from "@/components/print-invoice-button";
import { money } from "@/components/product-card";
import { db } from "@/db";
import { orderItems, orders } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { company } from "@/lib/demo-data";
import { and, eq } from "drizzle-orm";
import { Check, ChevronLeft, MapPin, Package, ShieldCheck, Truck } from "lucide-react";
import type { Metadata } from "next";
import Link from "next/link";
import { notFound, redirect } from "next/navigation";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Order Details", robots: { index: false, follow: false } };
type Props = { params: Promise<{ orderNumber: string }> };
export default async function OrderDetailPage({ params }: Props) {
  const user = await getCurrentUser(); if (!user) redirect("/login");
  const { orderNumber } = await params;
  const condition = user.role === "admin" ? eq(orders.orderNumber, orderNumber) : and(eq(orders.orderNumber, orderNumber), eq(orders.userId, user.id));
  const [order] = await db.select().from(orders).where(condition).limit(1);
  if (!order) notFound();
  const items = await db.select().from(orderItems).where(eq(orderItems.orderId, order.id));
  const address = order.addressSnapshot;
  const steps = ["placed", "confirmed", "packed", "shipped", "out_for_delivery", "delivered"];
  const activeIndex = steps.indexOf(order.status);
  return <main className="order-detail-page"><nav className="breadcrumb shell no-print"><Link href="/account/orders"><ChevronLeft /> My orders</Link><span>›</span><strong>{order.orderNumber}</strong></nav><section className="shell"><div className="order-detail-head no-print"><div><p>ORDER DETAILS</p><h1>{order.orderNumber}</h1><span>Placed on {new Date(order.placedAt).toLocaleString("en-IN", { dateStyle: "long", timeStyle: "short" })}</span></div><PrintInvoiceButton /></div><div className="order-progress no-print">{steps.map((step, index) => <div className={index <= activeIndex ? "active" : ""} key={step}><span>{index < activeIndex ? <Check /> : index + 1}</span><b>{step.replaceAll("_", " ")}</b>{index < steps.length - 1 && <i />}</div>)}</div><div className="order-meta no-print"><div><MapPin /><span><small>DELIVER TO</small><strong>{address.fullName}</strong><p>{address.house}, {address.street && `${address.street}, `}{address.area}, {address.city}, {address.state} — {address.pincode}</p><p>+91 {address.mobile}</p></span></div><div><Truck /><span><small>SHIPPING</small><strong>{order.courierName ?? "Awaiting courier assignment"}</strong><p>{order.trackingNumber ? `Tracking: ${order.trackingNumber}` : "Tracking will appear after dispatch."}</p></span></div><div><ShieldCheck /><span><small>PAYMENT</small><strong>{order.paymentMethod.toUpperCase()}</strong><p>Status: {order.paymentStatus}</p></span></div></div>
    <article className="invoice" id="invoice"><header><div className="invoice-brand"><span>N</span><div><strong>NEWTAS</strong><small>FOODS AND AGRO PRIVATE LIMITED</small></div></div><div><h2>TAX INVOICE</h2><p>Invoice no: INV-{order.orderNumber}</p><p>Invoice date: {new Date(order.placedAt).toLocaleDateString("en-IN")}</p></div></header><div className="invoice-parties"><div><small>SUPPLIER</small><strong>{company.name}</strong><p>{company.address}</p><p><b>GSTIN:</b> {company.gstin}</p><p><b>Email:</b> {company.email}</p></div><div><small>BILL TO / SHIP TO</small><strong>{address.fullName}</strong><p>{address.house}, {address.street && `${address.street}, `}{address.area}, {address.city}, {address.state} — {address.pincode}</p><p><b>Mobile:</b> +91 {address.mobile}</p></div></div><div className="invoice-order-ref"><span><small>ORDER ID</small><strong>{order.orderNumber}</strong></span><span><small>PAYMENT METHOD</small><strong>{order.paymentMethod.toUpperCase()}</strong></span><span><small>PLACE OF SUPPLY</small><strong>{address.state}</strong></span></div><table><thead><tr><th>#</th><th>Product</th><th>HSN/SAC</th><th>Pack</th><th>Qty</th><th>Rate</th><th>GST</th><th>Amount</th></tr></thead><tbody>{items.map((item, index) => <tr key={item.id}><td>{index + 1}</td><td><strong>{item.productName}</strong><small>SKU: {item.sku}</small></td><td>{item.hsnCode ?? "—"}</td><td>{item.variantLabel}</td><td>{item.quantity}</td><td>{money(Number(item.unitPrice))}</td><td>{item.gstPercent}%<small>Included</small></td><td>{money(Number(item.lineTotal))}</td></tr>)}</tbody></table><div className="invoice-bottom"><div><Package /><p>Goods sold are packaged food products. Product-specific statutory information is available on the final pack label.</p></div><dl><div><dt>Subtotal</dt><dd>{money(Number(order.subtotal))}</dd></div><div><dt>Discount</dt><dd>− {money(Number(order.discount))}</dd></div><div><dt>Delivery</dt><dd>{money(Number(order.deliveryFee))}</dd></div><div><dt>Included GST</dt><dd>{money(Number(order.taxAmount))}</dd></div><div className="invoice-total"><dt>Total</dt><dd>{money(Number(order.total))}</dd></div></dl></div><footer><p>This is a computer-generated invoice. Final statutory invoice details are based on approved company and product records.</p><div><strong>For {company.name}</strong><span>Authorised Signatory</span></div></footer></article></section></main>;
}
