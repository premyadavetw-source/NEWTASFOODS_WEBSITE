import { AdminDashboard } from "@/components/admin-dashboard";
import { db } from "@/db";
import { businessSettings, categories, coupons, orders, reviews, users } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { getBusinessSettings, getCatalog } from "@/lib/catalog";
import { asc, desc } from "drizzle-orm";
import type { Metadata } from "next";
import { redirect } from "next/navigation";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Admin Dashboard", robots: { index: false, follow: false } };
export default async function AdminPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  if (user.role !== "admin") redirect("/account");
  const [products, categoryRows, orderRows, customerRows, couponRows, reviewRows, settings] = await Promise.all([
    getCatalog(),
    db.select().from(categories).orderBy(asc(categories.sortOrder)),
    db.select().from(orders).orderBy(desc(orders.placedAt)),
    db.select({ id: users.id, name: users.name, email: users.email, mobile: users.mobile, role: users.role, createdAt: users.createdAt }).from(users).orderBy(desc(users.createdAt)),
    db.select().from(coupons).orderBy(desc(coupons.createdAt)),
    db.select().from(reviews).orderBy(desc(reviews.createdAt)),
    getBusinessSettings(),
  ]);
  if (!("id" in settings)) redirect("/");
  return <AdminDashboard adminName={user.name} products={products} categories={categoryRows} orders={orderRows} customers={customerRows} coupons={couponRows} reviews={reviewRows} settings={settings} />;
}
