import { NextRequest } from "next/server";

export async function GET(request: NextRequest) {
  const pincode = request.nextUrl.searchParams.get("pincode") ?? "";
  if (!/^[1-9]\d{5}$/.test(pincode)) return Response.json({ available: false, message: "Enter a valid 6-digit Indian pincode." }, { status: 400 });
  const estimated = new Date(); estimated.setDate(estimated.getDate() + 5);
  return Response.json({ available: true, message: "Pincode accepted. Indicative delivery by", date: estimated.toLocaleDateString("en-IN", { weekday: "short", day: "numeric", month: "short" }), note: "Final serviceability and date require courier confirmation at dispatch." });
}
