import { db } from "@/db";
import { addresses } from "@/db/schema";
import { requireUser } from "@/lib/auth";
import { and, eq, ne } from "drizzle-orm";
import { z } from "zod";

const addressSchema = z.object({
  id: z.number().int().positive().optional(),
  fullName: z.string().trim().min(2).max(120),
  mobile: z.string().regex(/^[6-9]\d{9}$/),
  house: z.string().trim().min(1).max(160),
  street: z.string().trim().max(180).optional().default(""),
  area: z.string().trim().min(2).max(180),
  city: z.string().trim().min(2).max(100),
  state: z.string().trim().min(2).max(100),
  pincode: z.string().regex(/^[1-9]\d{5}$/),
  landmark: z.string().trim().max(180).optional().default(""),
  isDefault: z.boolean().optional().default(false),
});

export async function GET() {
  try {
    const user = await requireUser();
    return Response.json({ addresses: await db.select().from(addresses).where(eq(addresses.userId, user.id)) });
  } catch { return Response.json({ message: "Please sign in." }, { status: 401 }); }
}

export async function POST(request: Request) {
  try {
    const user = await requireUser();
    const input = addressSchema.parse(await request.json());
    const existing = await db.select({ id: addresses.id }).from(addresses).where(eq(addresses.userId, user.id)).limit(1);
    const makeDefault = input.isDefault || !existing.length;
    if (makeDefault) await db.update(addresses).set({ isDefault: false }).where(eq(addresses.userId, user.id));
    const [address] = await db.insert(addresses).values({ ...input, userId: user.id, isDefault: makeDefault }).returning();
    return Response.json({ address }, { status: 201 });
  } catch (error) {
    if (error instanceof z.ZodError) return Response.json({ message: "Please enter a complete valid address." }, { status: 400 });
    return Response.json({ message: "Unable to save address." }, { status: 401 });
  }
}

export async function PATCH(request: Request) {
  try {
    const user = await requireUser();
    const input = addressSchema.extend({ id: z.number().int().positive() }).parse(await request.json());
    if (input.isDefault) await db.update(addresses).set({ isDefault: false }).where(and(eq(addresses.userId, user.id), ne(addresses.id, input.id)));
    const [address] = await db.update(addresses).set(input).where(and(eq(addresses.id, input.id), eq(addresses.userId, user.id))).returning();
    if (!address) return Response.json({ message: "Address not found." }, { status: 404 });
    return Response.json({ address });
  } catch (error) {
    if (error instanceof z.ZodError) return Response.json({ message: "Please enter a complete valid address." }, { status: 400 });
    return Response.json({ message: "Unable to update address." }, { status: 401 });
  }
}

export async function DELETE(request: Request) {
  try {
    const user = await requireUser();
    const { id } = z.object({ id: z.number().int().positive() }).parse(await request.json());
    const [deleted] = await db.delete(addresses).where(and(eq(addresses.id, id), eq(addresses.userId, user.id))).returning({ id: addresses.id });
    if (!deleted) return Response.json({ message: "Address not found." }, { status: 404 });
    return Response.json({ ok: true });
  } catch { return Response.json({ message: "Unable to delete address." }, { status: 401 }); }
}
