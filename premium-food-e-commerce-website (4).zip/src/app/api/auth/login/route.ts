import { db } from "@/db";
import { users } from "@/db/schema";
import { createSession } from "@/lib/auth";
import { compare } from "bcryptjs";
import { eq, or } from "drizzle-orm";
import { z } from "zod";

const schema = z.object({ identity: z.string().trim().min(3).max(180), password: z.string().min(8).max(72) });

export async function POST(request: Request) {
  try {
    const input = schema.parse(await request.json());
    const identity = input.identity.toLowerCase();
    const [user] = await db.select().from(users).where(or(eq(users.email, identity), eq(users.mobile, input.identity))).limit(1);
    if (!user || !user.isActive || !(await compare(input.password, user.passwordHash))) return Response.json({ message: "Incorrect email/mobile or password." }, { status: 401 });
    await createSession(user.id);
    return Response.json({ user: { id: user.id, name: user.name, email: user.email, role: user.role } });
  } catch (error) {
    if (error instanceof z.ZodError) return Response.json({ message: "Enter a valid email/mobile and password." }, { status: 400 });
    return Response.json({ message: "Unable to sign in right now." }, { status: 500 });
  }
}
