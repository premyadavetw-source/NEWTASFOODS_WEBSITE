import { getCurrentUser } from "@/lib/auth";

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return Response.json({ message: "Not signed in." }, { status: 401 });
  return Response.json({ user });
}
