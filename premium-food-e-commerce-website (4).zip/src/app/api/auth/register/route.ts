import { db } from "@/db";
import { users } from "@/db/schema";
import { createSession } from "@/lib/auth";
import { ensureCatalogSeeded } from "@/lib/catalog";
import { hash } from "bcryptjs";
import { or, eq } from "drizzle-orm";
import { z } from "zod";

const schema = z.object({ name: z.string().trim().min(2).max(120), mobile: z.string().regex(/^[6-9]\d{9}$/), email: z.string().trim().toLowerCase().email().max(180), password: z.string().min(8).max(72) });

export async function POST(request: Request) {
  try {
    await ensureCatalogSeeded();
    const input = schema.parse(await request.json());
    const [existing] = await db.select({ id: users.id }).from(users).where(or(eq(users.email, input.email), eq(users.mobile, input.mobile))).limit(1);
    if (existing) return Response.json({ message: "An account already exists with this email or mobile number." }, { status: 409 });
    const passwordHash = await hash(input.password, 12);
    const role = process.env.ADMIN_EMAIL?.toLowerCase() === input.email ? "admin" as const : "customer" as const;
    const [user] = await db.insert(users).values({ ...input, passwordHash, role }).returning({ id: users.id, name: users.name, email: users.email });
    await createSession(user.id);
    return Response.json({ user }, { status: 201 });
  } catch (error) {
    if (error instanceof z.ZodError) return Response.json({ message: "Please enter valid registration details.", fields: error.flatten().fieldErrors }, { status: 400 });
    return Response.json({ message: "Unable to create the account right now." }, { status: 500 });
  }
}
