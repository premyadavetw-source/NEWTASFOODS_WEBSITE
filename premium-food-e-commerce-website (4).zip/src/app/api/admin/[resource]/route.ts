import { db } from "@/db";
import { businessSettings, categories, coupons, orders, products, productVariants, reviews } from "@/db/schema";
import { requireAdmin } from "@/lib/auth";
import { and, eq } from "drizzle-orm";
import { z } from "zod";

type Props = { params: Promise<{ resource: string }> };
const productSchema = z.object({ id: z.number().int().positive().optional(), name: z.string().trim().min(2).max(180), slug: z.string().trim().regex(/^[a-z0-9-]+$/), categoryId: z.number().int().positive(), shortDescription: z.string().trim().max(500).optional().default(""), description: z.string().trim().max(5000).optional().default(""), ingredients: z.string().trim().max(2000).optional().default(""), imageUrl: z.string().url(), fssai: z.string().trim().max(30).optional().default(""), hsnCode: z.string().trim().max(20).optional().default(""), gstPercent: z.number().min(0).max(28).default(5), isFeatured: z.boolean().default(false), isBestSeller: z.boolean().default(false), sku: z.string().trim().min(3).max(80), pack: z.string().trim().min(1).max(60), weightGrams: z.number().int().positive(), mrp: z.number().positive(), price: z.number().positive(), stock: z.number().int().nonnegative(), minimumStock: z.number().int().nonnegative().default(10), barcode: z.string().max(80).optional().default(""), batchNumber: z.string().max(80).optional().default("") });
const categorySchema = z.object({ id: z.number().int().positive().optional(), name: z.string().trim().min(2).max(100), slug: z.string().trim().regex(/^[a-z0-9-]+$/), description: z.string().trim().max(1000).optional().default(""), imageUrl: z.string().url().optional().or(z.literal("")), sortOrder: z.number().int().default(0) });
const couponSchema = z.object({ id: z.number().int().positive().optional(), code: z.string().trim().toUpperCase().min(2).max(40), description: z.string().max(500).optional().default(""), type: z.enum(["percentage", "flat"]), value: z.number().positive(), minimumOrder: z.number().nonnegative().default(0), maximumDiscount: z.number().positive().optional(), firstOrderOnly: z.boolean().default(false), isActive: z.boolean().default(true) });

export async function POST(request: Request, { params }: Props) {
  try {
    await requireAdmin(); const { resource } = await params; const body = await request.json();
    if (resource === "products") {
      const input = productSchema.parse(body);
      const [product] = await db.insert(products).values({ categoryId: input.categoryId, name: input.name, slug: input.slug, shortDescription: input.shortDescription, description: input.description, ingredients: input.ingredients, images: [input.imageUrl], fssai: input.fssai || null, hsnCode: input.hsnCode || null, gstPercent: String(input.gstPercent), isFeatured: input.isFeatured, isBestSeller: input.isBestSeller, keywords: `${input.name} NEWTAS` }).returning();
      await db.insert(productVariants).values({ productId: product.id, sku: input.sku, label: input.pack, weightGrams: input.weightGrams, mrp: String(input.mrp), price: String(input.price), stock: input.stock, minimumStock: input.minimumStock, barcode: input.barcode || null, batchNumber: input.batchNumber || null });
      return Response.json({ product }, { status: 201 });
    }
    if (resource === "categories") { const input = categorySchema.parse(body); const [category] = await db.insert(categories).values(input).returning(); return Response.json({ category }, { status: 201 }); }
    if (resource === "coupons") { const input = couponSchema.parse(body); const [coupon] = await db.insert(coupons).values({ ...input, value: String(input.value), minimumOrder: String(input.minimumOrder), maximumDiscount: input.maximumDiscount ? String(input.maximumDiscount) : null }).returning(); return Response.json({ coupon }, { status: 201 }); }
    return Response.json({ message: "Unknown admin resource." }, { status: 404 });
  } catch (error) {
    if (error instanceof z.ZodError) return Response.json({ message: "Please check all fields.", fields: error.flatten().fieldErrors }, { status: 400 });
    const message = error instanceof Error && (error.message === "UNAUTHORIZED" || error.message === "FORBIDDEN") ? "Admin access required." : "Unable to create this record.";
    return Response.json({ message }, { status: message === "Admin access required." ? 403 : 500 });
  }
}

export async function PATCH(request: Request, { params }: Props) {
  try {
    await requireAdmin(); const { resource } = await params; const body = await request.json();
    if (resource === "products") {
      const input = productSchema.extend({ id: z.number().int().positive() }).parse(body);
      const [product] = await db.update(products).set({ categoryId: input.categoryId, name: input.name, slug: input.slug, shortDescription: input.shortDescription, description: input.description, ingredients: input.ingredients, images: [input.imageUrl], fssai: input.fssai || null, hsnCode: input.hsnCode || null, gstPercent: String(input.gstPercent), isFeatured: input.isFeatured, isBestSeller: input.isBestSeller, updatedAt: new Date() }).where(eq(products.id, input.id)).returning();
      const [variant] = await db.select().from(productVariants).where(eq(productVariants.productId, input.id)).limit(1);
      if (variant) await db.update(productVariants).set({ sku: input.sku, label: input.pack, weightGrams: input.weightGrams, mrp: String(input.mrp), price: String(input.price), stock: input.stock, minimumStock: input.minimumStock, barcode: input.barcode || null, batchNumber: input.batchNumber || null }).where(eq(productVariants.id, variant.id));
      return Response.json({ product });
    }
    if (resource === "categories") { const input = categorySchema.extend({ id: z.number().int().positive() }).parse(body); const { id, ...values } = input; const [category] = await db.update(categories).set(values).where(eq(categories.id, id)).returning(); return Response.json({ category }); }
    if (resource === "coupons") { const input = couponSchema.extend({ id: z.number().int().positive() }).parse(body); const { id, ...values } = input; const [coupon] = await db.update(coupons).set({ ...values, value: String(values.value), minimumOrder: String(values.minimumOrder), maximumDiscount: values.maximumDiscount ? String(values.maximumDiscount) : null }).where(eq(coupons.id, id)).returning(); return Response.json({ coupon }); }
    if (resource === "orders") {
      const input = z.object({ id: z.number().int().positive(), status: z.enum(["placed", "confirmed", "packed", "shipped", "out_for_delivery", "delivered", "cancelled", "refunded"]), paymentStatus: z.enum(["pending", "paid", "failed", "refunded"]).optional(), trackingNumber: z.string().max(100).optional(), courierName: z.string().max(100).optional() }).parse(body);
      const [order] = await db.update(orders).set({ status: input.status, paymentStatus: input.paymentStatus, trackingNumber: input.trackingNumber, courierName: input.courierName, updatedAt: new Date() }).where(eq(orders.id, input.id)).returning(); return Response.json({ order });
    }
    if (resource === "reviews") { const input = z.object({ id: z.number().int().positive(), isApproved: z.boolean() }).parse(body); const [review] = await db.update(reviews).set({ isApproved: input.isApproved }).where(eq(reviews.id, input.id)).returning(); return Response.json({ review }); }
    if (resource === "settings") {
      const input = z.object({ id: z.number().int().positive(), companyName: z.string().min(2).max(180), brandName: z.string().min(2).max(80), email: z.string().email(), phone: z.string().max(20), whatsapp: z.string().max(20), address: z.string().max(1000), gstin: z.string().max(20), fssai: z.string().max(30).optional(), freeDeliveryThreshold: z.number().nonnegative(), standardDeliveryFee: z.number().nonnegative() }).parse(body);
      const { id, ...values } = input; const [settings] = await db.update(businessSettings).set({ ...values, fssai: values.fssai || null, freeDeliveryThreshold: String(values.freeDeliveryThreshold), standardDeliveryFee: String(values.standardDeliveryFee), updatedAt: new Date() }).where(eq(businessSettings.id, id)).returning(); return Response.json({ settings });
    }
    return Response.json({ message: "Unknown admin resource." }, { status: 404 });
  } catch (error) {
    if (error instanceof z.ZodError) return Response.json({ message: "Please check all fields.", fields: error.flatten().fieldErrors }, { status: 400 });
    return Response.json({ message: "Admin update failed." }, { status: 403 });
  }
}

export async function DELETE(request: Request, { params }: Props) {
  try {
    await requireAdmin(); const { resource } = await params; const { id } = z.object({ id: z.number().int().positive() }).parse(await request.json());
    if (resource === "products") await db.update(products).set({ isActive: false, updatedAt: new Date() }).where(eq(products.id, id));
    else if (resource === "categories") await db.delete(categories).where(eq(categories.id, id));
    else if (resource === "coupons") await db.delete(coupons).where(eq(coupons.id, id));
    else if (resource === "reviews") await db.delete(reviews).where(eq(reviews.id, id));
    else return Response.json({ message: "Delete is not available for this resource." }, { status: 400 });
    return Response.json({ ok: true });
  } catch { return Response.json({ message: "Admin delete failed." }, { status: 403 }); }
}
