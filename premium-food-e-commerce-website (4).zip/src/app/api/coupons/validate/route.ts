import { db } from "@/db";
import { coupons, orders } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { ensureCatalogSeeded } from "@/lib/catalog";
import { and, eq, gt, isNull, or } from "drizzle-orm";
import { z } from "zod";

export async function POST(request: Request) {
  try {
    const { code, subtotal } = z.object({ code: z.string().trim().toUpperCase().min(2).max(40), subtotal: z.number().nonnegative() }).parse(await request.json());
    await ensureCatalogSeeded();
    const [coupon] = await db.select().from(coupons).where(and(eq(coupons.code, code), eq(coupons.isActive, true), or(isNull(coupons.expiresAt), gt(coupons.expiresAt, new Date())))).limit(1);
    if (!coupon) return Response.json({ valid: false, message: "This coupon is invalid or has expired." }, { status: 400 });
    if (subtotal < Number(coupon.minimumOrder ?? 0)) return Response.json({ valid: false, message: `Add ₹${Math.ceil(Number(coupon.minimumOrder) - subtotal)} more to use ${code}.` }, { status: 400 });
    if (coupon.usageLimit && coupon.usageCount >= coupon.usageLimit) return Response.json({ valid: false, message: "This coupon has reached its usage limit." }, { status: 400 });
    if (coupon.firstOrderOnly) {
      const user = await getCurrentUser();
      if (user) { const prior = await db.select({ id: orders.id }).from(orders).where(eq(orders.userId, user.id)).limit(1); if (prior.length) return Response.json({ valid: false, message: "This coupon is valid on a first order only." }, { status: 400 }); }
    }
    const raw = coupon.type === "percentage" ? subtotal * Number(coupon.value) / 100 : Number(coupon.value);
    const discount = Math.min(raw, coupon.maximumDiscount ? Number(coupon.maximumDiscount) : raw, subtotal);
    return Response.json({ valid: true, code, discount: Math.round(discount), message: `${code} applied. You save ₹${Math.round(discount)}.` });
  } catch { return Response.json({ valid: false, message: "Enter a valid coupon code." }, { status: 400 }); }
}
