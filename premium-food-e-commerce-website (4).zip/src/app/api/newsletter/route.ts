import { db } from "@/db";
import { newsletterSubscribers } from "@/db/schema";
import { z } from "zod";

export async function POST(request: Request) {
  try {
    const { email } = z.object({ email: z.string().trim().toLowerCase().email().max(180) }).parse(await request.json());
    await db.insert(newsletterSubscribers).values({ email }).onConflictDoUpdate({ target: newsletterSubscribers.email, set: { isActive: true } });
    return Response.json({ ok: true }, { status: 201 });
  } catch { return Response.json({ message: "Enter a valid email address." }, { status: 400 }); }
}
