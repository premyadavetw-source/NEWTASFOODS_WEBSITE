import { db } from "@/db";
import { cartItems, carts, productVariants } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { ensureCatalogSeeded } from "@/lib/catalog";
import { eq, inArray } from "drizzle-orm";
import { z } from "zod";

const schema = z.object({ guestToken: z.string().uuid(), items: z.array(z.object({ variantId: z.number().int().positive(), quantity: z.number().int().min(1).max(20), savedForLater: z.boolean() })).max(100) });
export async function POST(request: Request) {
  try {
    const input = schema.parse(await request.json()); await ensureCatalogSeeded(); const user = await getCurrentUser();
    const existing = user ? await db.select().from(carts).where(eq(carts.userId, user.id)).limit(1) : await db.select().from(carts).where(eq(carts.guestToken, input.guestToken)).limit(1);
    const cart = existing[0] ?? (await db.insert(carts).values(user ? { userId: user.id, guestToken: input.guestToken } : { guestToken: input.guestToken }).returning())[0];
    await db.delete(cartItems).where(eq(cartItems.cartId, cart.id));
    if (input.items.length) {
      const ids = input.items.map((item) => item.variantId);
      const valid = await db.select({ id: productVariants.id }).from(productVariants).where(inArray(productVariants.id, ids));
      const validIds = new Set(valid.map((item) => item.id));
      const items = input.items.filter((item) => validIds.has(item.variantId)).map((item) => ({ ...item, cartId: cart.id }));
      if (items.length) await db.insert(cartItems).values(items);
    }
    return Response.json({ ok: true });
  } catch { return Response.json({ message: "Cart sync was not completed." }, { status: 400 }); }
}
