import { db } from "@/db";
import { contactMessages } from "@/db/schema";
import { z } from "zod";

const schema = z.object({ name: z.string().trim().min(2).max(120), mobile: z.string().regex(/^\d{10}$/), email: z.string().trim().toLowerCase().email().max(180), subject: z.string().trim().min(2).max(120), message: z.string().trim().min(10).max(3000) });
export async function POST(request: Request) {
  try { const input = schema.parse(await request.json()); await db.insert(contactMessages).values(input); return Response.json({ ok: true }, { status: 201 }); }
  catch { return Response.json({ message: "Please check the form details." }, { status: 400 }); }
}
