import { db } from "@/db";
import { coupons, orderItems, orders, products, productVariants } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { ensureCatalogSeeded } from "@/lib/catalog";
import { createPaymentIntent } from "@/lib/payments";
import { getShippingQuote } from "@/lib/shipping";
import { and, eq, gt, inArray, isNull, or, sql } from "drizzle-orm";
import { randomInt } from "node:crypto";
import { z } from "zod";

const addressSchema = z.object({ fullName: z.string().trim().min(2).max(120), mobile: z.string().regex(/^[6-9]\d{9}$/), email: z.string().trim().email().optional().or(z.literal("")), house: z.string().trim().min(1).max(160), street: z.string().trim().max(180).optional().default(""), area: z.string().trim().min(2).max(180), city: z.string().trim().min(2).max(100), state: z.string().trim().min(2).max(100), pincode: z.string().regex(/^[1-9]\d{5}$/), landmark: z.string().trim().max(180).optional().default("") });
const orderSchema = z.object({ address: addressSchema, items: z.array(z.object({ variantId: z.number().int().positive(), quantity: z.number().int().min(1).max(20) })).min(1).max(100), couponCode: z.string().trim().toUpperCase().max(40).optional(), paymentMethod: z.enum(["cod", "upi", "card", "netbanking", "wallet"]) });

export async function POST(request: Request) {
  try {
    const input = orderSchema.parse(await request.json());
    await ensureCatalogSeeded();
    const user = await getCurrentUser();
    const ids = Array.from(new Set(input.items.map((item) => item.variantId)));
    const variantRows = await db.select({ variant: productVariants, product: products }).from(productVariants).innerJoin(products, eq(productVariants.productId, products.id)).where(and(inArray(productVariants.id, ids), eq(productVariants.isActive, true), eq(products.isActive, true)));
    if (variantRows.length !== ids.length) return Response.json({ message: "One or more products are no longer available." }, { status: 409 });

    const lines = input.items.map((item) => {
      const row = variantRows.find((entry) => entry.variant.id === item.variantId)!;
      if (row.variant.stock < item.quantity) throw new Error(`LOW_STOCK:${row.product.name}`);
      return { ...item, row, lineTotal: Number(row.variant.price) * item.quantity };
    });
    const subtotal = lines.reduce((sum, line) => sum + line.lineTotal, 0);
    let discount = 0;
    let appliedCoupon: typeof coupons.$inferSelect | undefined;
    if (input.couponCode) {
      const [coupon] = await db.select().from(coupons).where(and(eq(coupons.code, input.couponCode), eq(coupons.isActive, true), or(isNull(coupons.expiresAt), gt(coupons.expiresAt, new Date())))).limit(1);
      if (!coupon || subtotal < Number(coupon.minimumOrder ?? 0) || (coupon.usageLimit && coupon.usageCount >= coupon.usageLimit)) return Response.json({ message: "The selected coupon is no longer eligible." }, { status: 400 });
      if (coupon.firstOrderOnly && user) { const prior = await db.select({ id: orders.id }).from(orders).where(eq(orders.userId, user.id)).limit(1); if (prior.length) return Response.json({ message: "This coupon is valid on a first order only." }, { status: 400 }); }
      const raw = coupon.type === "percentage" ? subtotal * Number(coupon.value) / 100 : Number(coupon.value);
      discount = Math.min(raw, coupon.maximumDiscount ? Number(coupon.maximumDiscount) : raw, subtotal);
      appliedCoupon = coupon;
    }
    const weight = lines.reduce((sum, line) => sum + (line.row.variant.weightGrams ?? 500) * line.quantity, 0);
    const quote = await getShippingQuote({ pincode: input.address.pincode, weightGrams: weight, orderValue: subtotal - discount });
    if (!quote.serviceable) return Response.json({ message: "Delivery is not available to this pincode." }, { status: 400 });
    const deliveryFee = quote.fee;
    const taxAmount = lines.reduce((sum, line) => {
      const rate = Number(line.row.product.gstPercent ?? 0);
      return sum + line.lineTotal * rate / (100 + rate);
    }, 0);
    const total = Math.max(0, subtotal - discount + deliveryFee);
    const now = new Date();
    const orderNumber = `NWT-${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}${String(now.getDate()).padStart(2, "0")}-${randomInt(10000, 99999)}`;

    if (input.paymentMethod !== "cod") {
      try {
        const intent = await createPaymentIntent({ orderNumber, amountPaise: Math.round(total * 100), customer: { name: input.address.fullName, email: input.address.email || undefined, mobile: input.address.mobile } });
        return Response.json({ requiresPayment: true, intent });
      } catch {
        return Response.json({ message: "Online payment gateway is not configured yet. No payment was attempted. Please choose Cash on Delivery where available." }, { status: 503 });
      }
    }

    const created = await db.transaction(async (tx) => {
      for (const line of lines) {
        const updated = await tx.update(productVariants).set({ stock: sql`${productVariants.stock} - ${line.quantity}` }).where(and(eq(productVariants.id, line.variantId), gt(productVariants.stock, line.quantity - 1))).returning({ id: productVariants.id });
        if (!updated.length) throw new Error(`LOW_STOCK:${line.row.product.name}`);
      }
      const [order] = await tx.insert(orders).values({
        orderNumber, userId: user?.id, status: "placed", paymentStatus: "pending", paymentMethod: input.paymentMethod,
        addressSnapshot: input.address, subtotal: String(subtotal), discount: String(Math.round(discount)), deliveryFee: String(deliveryFee), taxAmount: String(taxAmount.toFixed(2)), total: String(total), couponCode: appliedCoupon?.code,
      }).returning();
      await tx.insert(orderItems).values(lines.map((line) => ({ orderId: order.id, productId: line.row.product.id, variantId: line.row.variant.id, productName: line.row.product.name, variantLabel: line.row.variant.label, sku: line.row.variant.sku, hsnCode: line.row.product.hsnCode, quantity: line.quantity, unitPrice: line.row.variant.price, gstPercent: line.row.product.gstPercent, lineTotal: String(line.lineTotal) })));
      if (appliedCoupon) await tx.update(coupons).set({ usageCount: sql`${coupons.usageCount} + 1` }).where(eq(coupons.id, appliedCoupon.id));
      return order;
    });
    return Response.json({ order: { orderNumber: created.orderNumber, status: created.status, total: Number(created.total), placedAt: created.placedAt }, provisionalShipping: quote.provisional }, { status: 201 });
  } catch (error) {
    if (error instanceof z.ZodError) return Response.json({ message: "Please complete the address, cart and payment details." }, { status: 400 });
    if (error instanceof Error && error.message.startsWith("LOW_STOCK:")) return Response.json({ message: `${error.message.split(":")[1]} has insufficient stock.` }, { status: 409 });
    return Response.json({ message: "The order could not be placed. No payment was taken." }, { status: 500 });
  }
}
