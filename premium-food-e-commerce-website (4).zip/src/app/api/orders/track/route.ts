import { db } from "@/db";
import { orders } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextRequest } from "next/server";

export async function GET(request: NextRequest) {
  const orderNumber = (request.nextUrl.searchParams.get("order") ?? "").trim().toUpperCase();
  const mobile = (request.nextUrl.searchParams.get("mobile") ?? "").trim();
  if (!orderNumber || !/^\d{10}$/.test(mobile)) return Response.json({ message: "Enter a valid Order ID and mobile number." }, { status: 400 });
  const [order] = await db.select({ orderNumber: orders.orderNumber, status: orders.status, placedAt: orders.placedAt, trackingNumber: orders.trackingNumber, courierName: orders.courierName, address: orders.addressSnapshot }).from(orders).where(eq(orders.orderNumber, orderNumber)).limit(1);
  if (!order || String(order.address.mobile) !== mobile) return Response.json({ message: "No order matches those details." }, { status: 404 });
  return Response.json({ order: { orderNumber: order.orderNumber, status: order.status, placedAt: order.placedAt, trackingNumber: order.trackingNumber, courierName: order.courierName } });
}
