import { WishlistView } from "@/components/wishlist-view";
import type { Metadata } from "next";

export const metadata: Metadata = { title: "My Wishlist", robots: { index: false, follow: false } };
export default function WishlistPage() { return <WishlistView />; }
