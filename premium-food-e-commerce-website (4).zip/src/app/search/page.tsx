import { ProductListing } from "@/components/product-listing";
import { getCatalog } from "@/lib/catalog";
import { Search, TrendingUp } from "lucide-react";
import type { Metadata } from "next";
import Link from "next/link";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Search Products", description: "Search the NEWTAS catalog by product, category, brand or keyword.", robots: { index: false, follow: true } };

type Props = { searchParams: Promise<{ q?: string }> };
export default async function SearchPage({ searchParams }: Props) {
  const { q = "" } = await searchParams;
  const [results, recommendations] = await Promise.all([getCatalog({ query: q || undefined }), getCatalog({ sort: "popular", limit: 8 })]);
  const display = q && !results.length ? recommendations : results;
  return <main><nav className="breadcrumb shell"><Link href="/">Home</Link><span>›</span><strong>Search</strong></nav><section className="search-page-head"><div className="shell"><Search />{q ? <div><p>Search results for</p><h1>“{q}”</h1><span>{results.length} matching products</span></div> : <div><p>Find your pantry favourites</p><h1>Search NEWTAS products</h1><span>Try a name, category or ingredient.</span></div>}</div></section>{q && !results.length && <div className="no-search shell"><TrendingUp /><div><strong>No exact match found.</strong><span>Here are popular products you may like.</span></div></div>}<section className="listing-section shell"><ProductListing products={display} /></section></main>;
}
