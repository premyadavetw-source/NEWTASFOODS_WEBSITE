import { SearchX } from "lucide-react";
import Link from "next/link";
export default function NotFound() { return <main className="account-empty shell"><SearchX /><p className="eyebrow">404 • PAGE NOT FOUND</p><h1>This aisle is empty.</h1><p>The page may have moved, or the product is no longer active.</p><div style={{ display: "flex", gap: 8 }}><Link className="btn btn-primary" href="/shop">Browse products</Link><Link className="btn btn-outline" href="/">Go home</Link></div></main>; }
