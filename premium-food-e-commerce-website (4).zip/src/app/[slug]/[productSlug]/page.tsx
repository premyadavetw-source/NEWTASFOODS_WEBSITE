import { ProductDetail } from "@/components/product-detail";
import { getCatalog, getProduct } from "@/lib/catalog";
import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";

export const dynamic = "force-dynamic";
type Props = { params: Promise<{ slug: string; productSlug: string }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug, productSlug } = await params;
  const product = await getProduct(slug, productSlug);
  if (!product) return {};
  return { title: product.name, description: product.shortDescription, alternates: { canonical: `/${slug}/${productSlug}` }, openGraph: { title: `${product.name} | NEWTAS`, description: product.shortDescription, images: [product.image], type: "website" } };
}

export default async function ProductPage({ params }: Props) {
  const { slug, productSlug } = await params;
  const [product, all] = await Promise.all([getProduct(slug, productSlug), getCatalog()]);
  if (!product) notFound();
  const similar = all.filter((item) => item.category === product.category && item.id !== product.id).slice(0, 5);
  const together = all.filter((item) => item.category !== product.category).slice(0, 4);
  const suggested = all.filter((item) => item.id !== product.id && !similar.some((match) => match.id === item.id)).slice(5, 10);
  const productSchema = { "@context": "https://schema.org", "@type": "Product", name: product.name, image: product.images, description: product.shortDescription, sku: product.sku, brand: { "@type": "Brand", name: "NEWTAS" }, offers: { "@type": "Offer", priceCurrency: "INR", price: product.price, availability: product.stock > 0 ? "https://schema.org/InStock" : "https://schema.org/OutOfStock", url: `/${slug}/${productSlug}` } };
  const breadcrumbSchema = { "@context": "https://schema.org", "@type": "BreadcrumbList", itemListElement: [{ "@type": "ListItem", position: 1, name: "Home", item: "/" }, { "@type": "ListItem", position: 2, name: product.categoryName, item: `/${slug}` }, { "@type": "ListItem", position: 3, name: product.name }] };
  return <main><nav className="breadcrumb shell"><Link href="/">Home</Link><span>›</span><Link href={`/${slug}`}>{product.categoryName}</Link><span>›</span><strong>{product.name}</strong></nav><ProductDetail product={product} together={together} similar={similar} suggested={suggested} /><script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(productSchema) }} /><script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbSchema) }} /></main>;
}
