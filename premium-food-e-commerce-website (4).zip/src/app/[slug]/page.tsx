import { ContactForm, TrackOrderForm } from "@/components/support-forms";
import { ProductListing } from "@/components/product-listing";
import { getCatalog } from "@/lib/catalog";
import { company, demoCategories, policyContent } from "@/lib/demo-data";
import { ArrowRight, Building2, Check, Mail, MapPin, MessageCircle, Phone, Sparkles, Tag } from "lucide-react";
import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";

export const dynamic = "force-dynamic";

type Props = { params: Promise<{ slug: string }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const category = demoCategories.find((item) => item.slug === slug);
  const titles: Record<string, string> = { shop: "Shop All Products", offers: "Offers & Coupons", "about-us": "About Us", "contact-us": "Contact Us", faq: "Frequently Asked Questions", "track-order": "Track Your Order" };
  const policy = policyContent[slug];
  const title = category?.name ?? policy?.title ?? titles[slug];
  if (!title) return {};
  return { title, description: category?.description ?? policy?.intro ?? `${title} at NEWTAS Foods and Agro Private Limited.`, alternates: { canonical: `/${slug}` } };
}

function Breadcrumb({ current }: { current: string }) {
  return <nav className="breadcrumb shell" aria-label="Breadcrumb"><Link href="/">Home</Link><span>›</span><strong>{current}</strong></nav>;
}

const faq = [
  ["Are all products and prices final?", "No. The current catalog is demonstration data and is clearly marked. Authorized administrators can update products, pack sizes, prices, taxes, stock and product information before launch."],
  ["How can I check delivery availability?", "Use the pincode checker on a product page. Final availability and delivery estimates are confirmed again during checkout."],
  ["Which payment methods will be supported?", "The checkout is structured for UPI, cards, net banking, wallets and eligible Cash on Delivery. Online payment is enabled only after secure gateway credentials are configured."],
  ["Can I change or cancel an order?", "Contact support promptly. Available actions depend on payment, packing and shipment status."],
  ["How do refunds work?", "Approved refunds are processed through the original payment route where possible. See the Return & Refund Policy for editable launch terms."],
  ["Where can I find FSSAI and manufacturer information?", "Verified information will be visible on product pages and pack labels after it is entered by an authorized administrator. No placeholder is presented as a real licence."],
];

export default async function PublicPage({ params }: Props) {
  const { slug } = await params;
  const category = demoCategories.find((item) => item.slug === slug);
  if (category || slug === "shop") {
    const products = await getCatalog({ category: category?.slug });
    const title = category?.name ?? "All products";
    return <main><Breadcrumb current={title} /><section className="category-hero"><div className="shell"><div><p>NEWTAS COLLECTION</p><h1>{title}</h1><span>{category?.description ?? "Explore our complete sample pantry collection across dry fruits, dates, seeds, spices and grocery."}</span><small>Sample catalog • Product data editable in admin</small></div>{category && <div className="category-hero-image"><Image src={category.image} alt={category.name} fill priority sizes="40vw" /></div>}</div></section><section className="listing-section shell"><ProductListing products={products} category={category?.slug} /></section></main>;
  }

  if (slug === "offers") {
    const offers = [
      { code: "NEW100", title: "Flat ₹100 off", terms: "On sample orders of ₹999 or more" },
      { code: "FIRSTORDER", title: "10% first-order saving", terms: "Above ₹499, maximum discount ₹150" },
      { code: "WELCOME10", title: "10% welcome offer", terms: "Above ₹599, maximum discount ₹100" },
    ];
    return <main><Breadcrumb current="Offers" /><section className="simple-hero"><div className="shell"><p>Thoughtful value</p><h1>Offers that keep things simple.</h1><span>Transparent codes, clear minimums and no confusing claims.</span></div></section><section className="section shell"><div className="offers-grid">{offers.map((offer) => <div className="coupon-card" key={offer.code}><Tag /><p>LIMITED PERIOD DEMO OFFER</p><h2>{offer.title}</h2><span>{offer.terms}</span><div><code>{offer.code}</code><Link href="/shop">Shop now <ArrowRight /></Link></div></div>)}</div><p className="offer-disclaimer">Offers are demonstration entries and remain editable or removable in the admin panel. Eligibility is validated server-side at checkout.</p></section></main>;
  }

  if (slug === "about-us") {
    return <main><Breadcrumb current="About Us" /><section className="about-hero"><div className="shell"><div><p>Our company</p><h1>Better pantry choices, built with care.</h1><span>{company.name} is an Indian packaged food and FMCG company based in Etawah, Uttar Pradesh.</span></div><div className="about-mark">N<span>Newtas</span></div></div></section><section className="section shell about-grid"><div><p className="eyebrow">Who we are</p><h2>A focused Indian food brand for modern households.</h2><p>NEWTAS is building a considered selection of dry fruits, dates, seeds, spices, masala and grocery essentials. Our digital store is designed around clear product information, dependable inventory controls and accessible customer support.</p><p>All regulatory product details, prices and claims remain editable so the company can publish only verified, approved information.</p></div><aside><Building2 /><h3>Registered business details</h3><dl><div><dt>Legal name</dt><dd>{company.name}</dd></div><div><dt>GSTIN</dt><dd>{company.gstin}</dd></div><div><dt>Registered address</dt><dd>{company.address}</dd></div><div><dt>Email</dt><dd>{company.email}</dd></div></dl></aside></section><section className="directors-section"><div className="shell"><p className="eyebrow">Leadership</p><h2>Company directors</h2><div className="director-grid">{company.directors.map((director, index) => <div key={director.name}><span>0{index + 1}</span><div><h3>{director.name}</h3><p>Director</p><a href={`tel:+91${director.phone}`}><Phone /> +91 {director.phone}</a></div></div>)}</div></div></section></main>;
  }

  if (slug === "contact-us") {
    return <main><Breadcrumb current="Contact Us" /><section className="simple-hero"><div className="shell"><p>We’re here to help</p><h1>Talk to the NEWTAS team.</h1><span>Product question, order support or business enquiry—we’ll route it to the right person.</span></div></section><section className="section shell contact-layout"><div className="contact-details"><p className="eyebrow">Contact details</p><h2>Reach us directly.</h2><a href={`mailto:${company.email}`}><Mail /><span><small>Email</small><strong>{company.email}</strong></span></a><a href={`tel:+91${company.directors[0].phone}`}><Phone /><span><small>Phone</small><strong>+91 {company.directors[0].phone}</strong></span></a><a href={`https://wa.me/91${company.directors[0].phone}`}><MessageCircle /><span><small>WhatsApp</small><strong>Start a conversation</strong></span></a><div><MapPin /><span><small>Business address</small><strong>{company.address}</strong></span></div></div><div><p className="eyebrow">Send an enquiry</p><h2>How can we help?</h2><ContactForm /></div></section></main>;
  }

  if (slug === "faq") {
    const schema = { "@context": "https://schema.org", "@type": "FAQPage", mainEntity: faq.map(([question, answer]) => ({ "@type": "Question", name: question, acceptedAnswer: { "@type": "Answer", text: answer } })) };
    return <main><Breadcrumb current="FAQ" /><section className="simple-hero"><div className="shell"><p>Help centre</p><h1>Frequently asked questions.</h1><span>Clear answers about shopping, delivery, payment and product information.</span></div></section><section className="section shell faq-list">{faq.map(([question, answer], index) => <details key={question} open={index === 0}><summary><span>{String(index + 1).padStart(2, "0")}</span>{question}<b>+</b></summary><p>{answer}</p></details>)}</section><script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }} /></main>;
  }

  if (slug === "track-order") return <main><Breadcrumb current="Track Order" /><section className="simple-hero"><div className="shell"><p>Delivery updates</p><h1>Track your order.</h1><span>Enter the Order ID and mobile number used at checkout.</span></div></section><section className="section shell narrow-page"><TrackOrderForm /></section></main>;

  const policy = policyContent[slug];
  if (policy) return <main><Breadcrumb current={policy.title} /><section className="policy-layout shell"><aside><p>{policy.eyebrow}</p><h1>{policy.title}</h1><span>Last reviewed: launch draft</span></aside><article><p className="policy-intro">{policy.intro}</p>{policy.sections.map((section) => <section key={section.title}><h2>{section.title}</h2><p>{section.body}</p></section>)}<div className="policy-note"><Check /> This policy is an editable launch draft. Final approved terms should be reviewed by the company before accepting live orders.</div></article></section></main>;

  notFound();
}
