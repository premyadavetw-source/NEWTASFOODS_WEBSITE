import type { Metadata } from "next";
import type { ReactNode } from "react";
import { CommerceProvider } from "@/components/commerce-provider";
import { SiteChrome } from "@/components/site-chrome";
import { company } from "@/lib/demo-data";
import { MessageCircle } from "lucide-react";
import "./globals.css";

const siteUrl = process.env.NEXT_PUBLIC_SITE_URL ?? "https://newtasfoods.com";

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: { default: "NEWTAS Foods & Agro | Premium Dry Fruits, Spices & Grocery", template: "%s | NEWTAS" },
  description: "Shop premium dry fruits, dates, seeds, spices, masala and everyday grocery from NEWTAS Foods and Agro Private Limited.",
  keywords: ["NEWTAS", "dry fruits online", "dates", "seeds", "Indian spices", "grocery India", "premium packaged foods"],
  alternates: { canonical: "/" },
  openGraph: { title: "NEWTAS Foods & Agro", description: "Pure ingredients. Better living.", url: siteUrl, siteName: "NEWTAS", locale: "en_IN", type: "website" },
  robots: { index: true, follow: true },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  const organization = {
    "@context": "https://schema.org",
    "@type": "Organization",
    name: company.name,
    brand: company.brand,
    email: company.email,
    taxID: company.gstin,
    address: { "@type": "PostalAddress", streetAddress: "Shastri Colony, Behind New Mandi", addressLocality: "Etawah", addressRegion: "Uttar Pradesh", addressCountry: "IN" },
    contactPoint: company.directors.map((director) => ({ "@type": "ContactPoint", name: director.name, telephone: `+91-${director.phone}`, contactType: "customer support", areaServed: "IN" })),
  };
  return (
    <html lang="en-IN">
      <body>
        <CommerceProvider>
          <SiteChrome>{children}</SiteChrome>
          <a className="whatsapp-float" href={`https://wa.me/91${company.directors[0].phone}`} target="_blank" rel="noreferrer" aria-label="Chat with NEWTAS on WhatsApp"><MessageCircle /></a>
        </CommerceProvider>
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(organization).replace(/</g, "\\u003c") }} />
      </body>
    </html>
  );
}
