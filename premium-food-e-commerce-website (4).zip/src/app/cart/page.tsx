import { CartView } from "@/components/cart-view";
import { getCatalog } from "@/lib/catalog";
import type { Metadata } from "next";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Shopping Cart", robots: { index: false, follow: false } };
export default async function CartPage() {
  const recommended = await getCatalog({ sort: "popular", limit: 5 });
  return <CartView recommended={recommended} />;
}
