import { CheckoutView } from "@/components/checkout-view";
import type { Metadata } from "next";
export const metadata: Metadata = { title: "Secure Checkout", robots: { index: false, follow: false } };
export default function CheckoutPage() { return <CheckoutView />; }
