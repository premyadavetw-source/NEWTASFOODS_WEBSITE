import {
  boolean,
  date,
  index,
  integer,
  jsonb,
  numeric,
  pgEnum,
  pgTable,
  serial,
  text,
  timestamp,
  uniqueIndex,
  varchar,
} from "drizzle-orm/pg-core";

export const userRoleEnum = pgEnum("user_role", ["customer", "admin"]);
export const orderStatusEnum = pgEnum("order_status", [
  "placed",
  "confirmed",
  "packed",
  "shipped",
  "out_for_delivery",
  "delivered",
  "cancelled",
  "refunded",
]);
export const paymentStatusEnum = pgEnum("payment_status", ["pending", "paid", "failed", "refunded"]);
export const discountTypeEnum = pgEnum("discount_type", ["percentage", "flat"]);

export const businessSettings = pgTable("business_settings", {
  id: serial("id").primaryKey(),
  companyName: varchar("company_name", { length: 180 }).notNull(),
  brandName: varchar("brand_name", { length: 80 }).notNull().default("NEWTAS"),
  email: varchar("email", { length: 180 }),
  phone: varchar("phone", { length: 20 }),
  whatsapp: varchar("whatsapp", { length: 20 }),
  address: text("address"),
  gstin: varchar("gstin", { length: 20 }),
  fssai: varchar("fssai", { length: 30 }),
  directors: jsonb("directors").$type<Array<{ name: string; phone: string }>>().default([]),
  freeDeliveryThreshold: numeric("free_delivery_threshold", { precision: 10, scale: 2 }).default("499"),
  standardDeliveryFee: numeric("standard_delivery_fee", { precision: 10, scale: 2 }).default("49"),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

export const categories = pgTable(
  "categories",
  {
    id: serial("id").primaryKey(),
    name: varchar("name", { length: 100 }).notNull(),
    slug: varchar("slug", { length: 120 }).notNull(),
    description: text("description"),
    imageUrl: text("image_url"),
    isActive: boolean("is_active").default(true).notNull(),
    sortOrder: integer("sort_order").default(0).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [uniqueIndex("categories_slug_idx").on(table.slug)],
);

export const products = pgTable(
  "products",
  {
    id: serial("id").primaryKey(),
    categoryId: integer("category_id").references(() => categories.id, { onDelete: "set null" }),
    name: varchar("name", { length: 180 }).notNull(),
    slug: varchar("slug", { length: 200 }).notNull(),
    brand: varchar("brand", { length: 80 }).default("NEWTAS").notNull(),
    shortDescription: text("short_description"),
    description: text("description"),
    ingredients: text("ingredients"),
    nutrition: jsonb("nutrition").$type<Record<string, string>>().default({}),
    allergenInfo: text("allergen_info"),
    storageInstructions: text("storage_instructions"),
    shelfLifeMonths: integer("shelf_life_months"),
    countryOfOrigin: varchar("country_of_origin", { length: 80 }).default("India"),
    manufacturerDetails: text("manufacturer_details"),
    fssai: varchar("fssai", { length: 30 }),
    hsnCode: varchar("hsn_code", { length: 20 }),
    gstPercent: numeric("gst_percent", { precision: 5, scale: 2 }).default("5"),
    images: jsonb("images").$type<string[]>().default([]),
    keywords: text("keywords"),
    rating: numeric("rating", { precision: 2, scale: 1 }).default("0"),
    reviewCount: integer("review_count").default(0).notNull(),
    isFeatured: boolean("is_featured").default(false).notNull(),
    isBestSeller: boolean("is_best_seller").default(false).notNull(),
    isNew: boolean("is_new").default(false).notNull(),
    isActive: boolean("is_active").default(true).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [uniqueIndex("products_slug_idx").on(table.slug), index("products_category_idx").on(table.categoryId)],
);

export const productVariants = pgTable(
  "product_variants",
  {
    id: serial("id").primaryKey(),
    productId: integer("product_id").notNull().references(() => products.id, { onDelete: "cascade" }),
    sku: varchar("sku", { length: 80 }).notNull(),
    barcode: varchar("barcode", { length: 80 }),
    label: varchar("label", { length: 60 }).notNull(),
    weightGrams: integer("weight_grams"),
    mrp: numeric("mrp", { precision: 10, scale: 2 }).notNull(),
    price: numeric("price", { precision: 10, scale: 2 }).notNull(),
    stock: integer("stock").default(0).notNull(),
    minimumStock: integer("minimum_stock").default(10).notNull(),
    batchNumber: varchar("batch_number", { length: 80 }),
    manufacturingDate: date("manufacturing_date"),
    expiryDate: date("expiry_date"),
    isActive: boolean("is_active").default(true).notNull(),
  },
  (table) => [uniqueIndex("variants_sku_idx").on(table.sku), index("variants_product_idx").on(table.productId)],
);

export const users = pgTable(
  "users",
  {
    id: serial("id").primaryKey(),
    name: varchar("name", { length: 120 }).notNull(),
    email: varchar("email", { length: 180 }).notNull(),
    mobile: varchar("mobile", { length: 20 }).notNull(),
    passwordHash: text("password_hash").notNull(),
    role: userRoleEnum("role").default("customer").notNull(),
    isActive: boolean("is_active").default(true).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [uniqueIndex("users_email_idx").on(table.email), uniqueIndex("users_mobile_idx").on(table.mobile)],
);

export const sessions = pgTable(
  "sessions",
  {
    id: varchar("id", { length: 128 }).primaryKey(),
    userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [index("sessions_user_idx").on(table.userId)],
);

export const addresses = pgTable("addresses", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  fullName: varchar("full_name", { length: 120 }).notNull(),
  mobile: varchar("mobile", { length: 20 }).notNull(),
  house: varchar("house", { length: 160 }).notNull(),
  street: varchar("street", { length: 180 }),
  area: varchar("area", { length: 180 }).notNull(),
  city: varchar("city", { length: 100 }).notNull(),
  state: varchar("state", { length: 100 }).notNull(),
  pincode: varchar("pincode", { length: 10 }).notNull(),
  landmark: varchar("landmark", { length: 180 }),
  isDefault: boolean("is_default").default(false).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const carts = pgTable("carts", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id, { onDelete: "cascade" }),
  guestToken: varchar("guest_token", { length: 128 }),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

export const cartItems = pgTable(
  "cart_items",
  {
    id: serial("id").primaryKey(),
    cartId: integer("cart_id").notNull().references(() => carts.id, { onDelete: "cascade" }),
    variantId: integer("variant_id").notNull().references(() => productVariants.id, { onDelete: "cascade" }),
    quantity: integer("quantity").default(1).notNull(),
    savedForLater: boolean("saved_for_later").default(false).notNull(),
  },
  (table) => [uniqueIndex("cart_variant_idx").on(table.cartId, table.variantId)],
);

export const wishlistItems = pgTable(
  "wishlist_items",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    productId: integer("product_id").notNull().references(() => products.id, { onDelete: "cascade" }),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [uniqueIndex("wishlist_product_idx").on(table.userId, table.productId)],
);

export const coupons = pgTable(
  "coupons",
  {
    id: serial("id").primaryKey(),
    code: varchar("code", { length: 40 }).notNull(),
    description: text("description"),
    type: discountTypeEnum("type").notNull(),
    value: numeric("value", { precision: 10, scale: 2 }).notNull(),
    minimumOrder: numeric("minimum_order", { precision: 10, scale: 2 }).default("0"),
    maximumDiscount: numeric("maximum_discount", { precision: 10, scale: 2 }),
    categoryId: integer("category_id").references(() => categories.id, { onDelete: "set null" }),
    firstOrderOnly: boolean("first_order_only").default(false).notNull(),
    expiresAt: timestamp("expires_at", { withTimezone: true }),
    usageLimit: integer("usage_limit"),
    usageCount: integer("usage_count").default(0).notNull(),
    isActive: boolean("is_active").default(true).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [uniqueIndex("coupons_code_idx").on(table.code)],
);

export const orders = pgTable(
  "orders",
  {
    id: serial("id").primaryKey(),
    orderNumber: varchar("order_number", { length: 40 }).notNull(),
    userId: integer("user_id").references(() => users.id, { onDelete: "set null" }),
    status: orderStatusEnum("status").default("placed").notNull(),
    paymentStatus: paymentStatusEnum("payment_status").default("pending").notNull(),
    paymentMethod: varchar("payment_method", { length: 40 }).notNull(),
    paymentReference: varchar("payment_reference", { length: 160 }),
    addressSnapshot: jsonb("address_snapshot").$type<Record<string, string>>().notNull(),
    subtotal: numeric("subtotal", { precision: 12, scale: 2 }).notNull(),
    discount: numeric("discount", { precision: 12, scale: 2 }).default("0").notNull(),
    deliveryFee: numeric("delivery_fee", { precision: 10, scale: 2 }).default("0").notNull(),
    taxAmount: numeric("tax_amount", { precision: 10, scale: 2 }).default("0").notNull(),
    total: numeric("total", { precision: 12, scale: 2 }).notNull(),
    couponCode: varchar("coupon_code", { length: 40 }),
    trackingNumber: varchar("tracking_number", { length: 100 }),
    courierName: varchar("courier_name", { length: 100 }),
    placedAt: timestamp("placed_at", { withTimezone: true }).defaultNow().notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [uniqueIndex("orders_number_idx").on(table.orderNumber), index("orders_user_idx").on(table.userId)],
);

export const orderItems = pgTable("order_items", {
  id: serial("id").primaryKey(),
  orderId: integer("order_id").notNull().references(() => orders.id, { onDelete: "cascade" }),
  productId: integer("product_id").references(() => products.id, { onDelete: "set null" }),
  variantId: integer("variant_id").references(() => productVariants.id, { onDelete: "set null" }),
  productName: varchar("product_name", { length: 180 }).notNull(),
  variantLabel: varchar("variant_label", { length: 60 }).notNull(),
  sku: varchar("sku", { length: 80 }).notNull(),
  hsnCode: varchar("hsn_code", { length: 20 }),
  quantity: integer("quantity").notNull(),
  unitPrice: numeric("unit_price", { precision: 10, scale: 2 }).notNull(),
  gstPercent: numeric("gst_percent", { precision: 5, scale: 2 }).default("5"),
  lineTotal: numeric("line_total", { precision: 12, scale: 2 }).notNull(),
});

export const reviews = pgTable("reviews", {
  id: serial("id").primaryKey(),
  productId: integer("product_id").notNull().references(() => products.id, { onDelete: "cascade" }),
  userId: integer("user_id").references(() => users.id, { onDelete: "set null" }),
  rating: integer("rating").notNull(),
  title: varchar("title", { length: 140 }),
  body: text("body").notNull(),
  isApproved: boolean("is_approved").default(false).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const newsletterSubscribers = pgTable("newsletter_subscribers", {
  id: serial("id").primaryKey(),
  email: varchar("email", { length: 180 }).notNull(),
  isActive: boolean("is_active").default(true).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
}, (table) => [uniqueIndex("newsletter_email_idx").on(table.email)]);

export const contactMessages = pgTable("contact_messages", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 120 }).notNull(),
  mobile: varchar("mobile", { length: 20 }).notNull(),
  email: varchar("email", { length: 180 }).notNull(),
  subject: varchar("subject", { length: 120 }).notNull(),
  message: text("message").notNull(),
  status: varchar("status", { length: 30 }).default("new").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export type Product = typeof products.$inferSelect;
export type ProductVariant = typeof productVariants.$inferSelect;
export type Category = typeof categories.$inferSelect;
export type Order = typeof orders.$inferSelect;
