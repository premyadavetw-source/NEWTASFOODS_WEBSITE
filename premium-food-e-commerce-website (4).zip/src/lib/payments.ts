import "server-only";

export type PaymentProvider = "razorpay" | "cashfree" | "phonepe";
export type PaymentIntent = { provider: PaymentProvider; providerOrderId: string; publicKey?: string; amountPaise: number; currency: "INR" };

export function configuredPaymentProvider(): PaymentProvider | null {
  const provider = process.env.PAYMENT_PROVIDER?.toLowerCase();
  if (provider === "razorpay" || provider === "cashfree" || provider === "phonepe") return provider;
  return null;
}

export async function createPaymentIntent(_input: { orderNumber: string; amountPaise: number; customer: { name: string; email?: string; mobile: string } }): Promise<PaymentIntent> {
  const provider = configuredPaymentProvider();
  if (!provider) throw new Error("PAYMENT_GATEWAY_NOT_CONFIGURED");
  // Provider adapters belong here. Each adapter must create an order with the official
  // server API, return only public checkout data, and verify the signed callback/webhook
  // before marking a NEWTAS order paid. Secrets must never be sent to the browser.
  throw new Error(`${provider.toUpperCase()}_ADAPTER_NOT_CONFIGURED`);
}
