import "server-only";

export type ShippingQuote = { serviceable: boolean; fee: number; estimatedDays: number; provider?: string; provisional: boolean };
export async function getShippingQuote(input: { pincode: string; weightGrams: number; orderValue: number }): Promise<ShippingQuote> {
  if (!/^[1-9]\d{5}$/.test(input.pincode)) return { serviceable: false, fee: 0, estimatedDays: 0, provisional: true };
  const configured = process.env.SHIPPING_PROVIDER;
  if (configured) {
    // Official Shiprocket, Delhivery or Blue Dart quote/serviceability adapters plug in here.
    // The implementation must keep API tokens server-side and persist courier references only.
  }
  return { serviceable: true, fee: input.orderValue >= 499 ? 0 : 49, estimatedDays: 5, provider: configured, provisional: true };
}
