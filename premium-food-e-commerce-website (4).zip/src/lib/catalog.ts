import "server-only";

import { db } from "@/db";
import { businessSettings, categories, coupons, products, productVariants } from "@/db/schema";
import { and, asc, desc, eq, ilike, inArray, or, sql } from "drizzle-orm";
import { company, demoCategories, demoProducts, type DemoProduct } from "./demo-data";

let seedPromise: Promise<void> | null = null;

async function seedDatabase() {
  const existing = await db.select({ id: categories.id }).from(categories).limit(1);
  if (!existing.length) {
    const insertedCategories = await db
      .insert(categories)
      .values(demoCategories.map((category, index) => ({
        name: category.name,
        slug: category.slug,
        description: category.description,
        imageUrl: category.image,
        sortOrder: index + 1,
      })))
      .returning({ id: categories.id, slug: categories.slug });
    const categoryIds = Object.fromEntries(insertedCategories.map((category) => [category.slug, category.id]));

    for (const product of demoProducts) {
      const [inserted] = await db
        .insert(products)
        .values({
          categoryId: categoryIds[product.category],
          name: product.name,
          slug: product.slug,
          shortDescription: product.shortDescription,
          description: product.description,
          ingredients: product.ingredients,
          nutrition: product.nutrition,
          allergenInfo: "Check product label before use. Update verified allergen information in admin.",
          storageInstructions: "Store in a cool, dry place away from direct sunlight. Reseal after opening.",
          shelfLifeMonths: 9,
          countryOfOrigin: "India",
          manufacturerDetails: company.name,
          hsnCode: product.hsn,
          gstPercent: String(product.gstPercent),
          images: product.images,
          keywords: `${product.name} ${product.categoryName} NEWTAS premium food`,
          rating: String(product.rating),
          reviewCount: 0,
          isFeatured: product.featured,
          isBestSeller: product.bestSeller,
          isNew: product.isNew,
        })
        .returning({ id: products.id });

      await db.insert(productVariants).values(product.variants.map((variant) => ({
        productId: inserted.id,
        sku: variant.sku,
        label: variant.label,
        weightGrams: variant.weightGrams,
        mrp: String(variant.mrp),
        price: String(variant.price),
        stock: variant.stock,
        minimumStock: 10,
      })));
    }
  }

  const settings = await db.select({ id: businessSettings.id }).from(businessSettings).limit(1);
  if (!settings.length) {
    await db.insert(businessSettings).values({
      companyName: company.name,
      brandName: company.brand,
      email: company.email,
      phone: company.directors[0].phone,
      whatsapp: company.directors[0].phone,
      address: company.address,
      gstin: company.gstin,
      directors: company.directors,
    });
  }

  const existingCoupons = await db.select({ id: coupons.id }).from(coupons).limit(1);
  if (!existingCoupons.length) {
    const nextYear = new Date();
    nextYear.setFullYear(nextYear.getFullYear() + 1);
    await db.insert(coupons).values([
      { code: "NEW100", description: "₹100 off on orders above ₹999", type: "flat", value: "100", minimumOrder: "999", expiresAt: nextYear },
      { code: "FIRSTORDER", description: "10% off for first-time customers", type: "percentage", value: "10", minimumOrder: "499", maximumDiscount: "150", firstOrderOnly: true, expiresAt: nextYear },
      { code: "WELCOME10", description: "10% welcome offer up to ₹100", type: "percentage", value: "10", minimumOrder: "599", maximumDiscount: "100", expiresAt: nextYear },
    ]);
  }
}

export async function ensureCatalogSeeded() {
  if (!seedPromise) seedPromise = seedDatabase().catch((error) => {
    seedPromise = null;
    throw error;
  });
  return seedPromise;
}

function getFallbackProducts(query?: string, category?: string) {
  let result = [...demoProducts];
  if (category && category !== "shop") result = result.filter((product) => product.category === category);
  if (query) {
    const needle = query.toLowerCase();
    result = result.filter((product) => `${product.name} ${product.categoryName} ${product.shortDescription}`.toLowerCase().includes(needle));
  }
  return result;
}

export type CatalogSort = "popular" | "newest" | "price-low" | "price-high" | "rating" | "discount";

export async function getCatalog(options: { query?: string; category?: string; sort?: CatalogSort; limit?: number } = {}): Promise<DemoProduct[]> {
  const { query, category, sort = "popular", limit } = options;
  try {
    await ensureCatalogSeeded();
    const conditions = [eq(products.isActive, true)];
    if (category && category !== "shop") conditions.push(eq(categories.slug, category));
    if (query) {
      const search = `%${query}%`;
      conditions.push(or(ilike(products.name, search), ilike(products.keywords, search), ilike(categories.name, search))!);
    }

    const ordering = sort === "newest" ? desc(products.createdAt)
      : sort === "rating" ? desc(products.rating)
      : sort === "price-low" ? asc(sql`(select min(${productVariants.price}) from ${productVariants} where ${productVariants.productId} = ${products.id})`)
      : sort === "price-high" ? desc(sql`(select min(${productVariants.price}) from ${productVariants} where ${productVariants.productId} = ${products.id})`)
      : desc(products.isBestSeller);

    const rows = await db
      .select({ product: products, category: categories })
      .from(products)
      .leftJoin(categories, eq(products.categoryId, categories.id))
      .where(and(...conditions))
      .orderBy(ordering, asc(products.id))
      .limit(limit ?? 200);

    const productIds = rows.map((row) => row.product.id);
    const variants = productIds.length
      ? await db.select().from(productVariants).where(and(inArray(productVariants.productId, productIds), eq(productVariants.isActive, true))).orderBy(asc(productVariants.id))
      : [];

    return rows.map(({ product, category: categoryRow }) => {
      const productOptions = variants.filter((variant) => variant.productId === product.id);
      const first = productOptions[0];
      const images = (product.images ?? []) as string[];
      return {
        id: product.id,
        name: product.name,
        slug: product.slug,
        category: categoryRow?.slug ?? "shop",
        categoryName: categoryRow?.name ?? "Products",
        shortDescription: product.shortDescription ?? "Premium NEWTAS packaged food product.",
        description: product.description ?? "Product information can be managed from the admin panel.",
        ingredients: product.ingredients ?? "See pack label",
        image: images[0] ?? demoProducts[0].image,
        images: images.length ? images : [demoProducts[0].image],
        mrp: Number(first?.mrp ?? 0),
        price: Number(first?.price ?? 0),
        rating: Number(product.rating ?? 0),
        reviewCount: product.reviewCount,
        pack: first?.label ?? "Standard pack",
        stock: first?.stock ?? 0,
        sku: first?.sku ?? `NWT-${product.id}`,
        hsn: product.hsnCode ?? "Editable in admin",
        gstPercent: Number(product.gstPercent ?? 0),
        featured: product.isFeatured,
        bestSeller: product.isBestSeller,
        isNew: product.isNew,
        variants: productOptions.map((variant) => ({
          id: variant.id,
          label: variant.label,
          weightGrams: variant.weightGrams ?? 0,
          mrp: Number(variant.mrp),
          price: Number(variant.price),
          stock: variant.stock,
          sku: variant.sku,
        })),
        nutrition: (product.nutrition ?? {}) as Record<string, string>,
      };
    });
  } catch {
    let fallback = getFallbackProducts(query, category);
    if (sort === "price-low") fallback.sort((a, b) => a.price - b.price);
    if (sort === "price-high") fallback.sort((a, b) => b.price - a.price);
    if (sort === "rating") fallback.sort((a, b) => b.rating - a.rating);
    if (sort === "newest") fallback.sort((a, b) => Number(b.isNew) - Number(a.isNew));
    return limit ? fallback.slice(0, limit) : fallback;
  }
}

export async function getProduct(categorySlug: string, productSlug: string) {
  const matches = await getCatalog({ category: categorySlug });
  return matches.find((product) => product.slug === productSlug) ?? null;
}

export async function getBusinessSettings() {
  try {
    await ensureCatalogSeeded();
    const [settings] = await db.select().from(businessSettings).limit(1);
    return settings ?? company;
  } catch {
    return company;
  }
}
