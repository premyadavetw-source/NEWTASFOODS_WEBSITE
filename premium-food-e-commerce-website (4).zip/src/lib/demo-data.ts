export type DemoCategory = {
  name: string;
  slug: string;
  description: string;
  image: string;
};

export type DemoProduct = {
  id: number;
  name: string;
  slug: string;
  category: string;
  categoryName: string;
  shortDescription: string;
  description: string;
  ingredients: string;
  image: string;
  images: string[];
  mrp: number;
  price: number;
  rating: number;
  reviewCount: number;
  pack: string;
  stock: number;
  sku: string;
  hsn: string;
  gstPercent: number;
  featured: boolean;
  bestSeller: boolean;
  isNew: boolean;
  variants: Array<{ id: number; label: string; weightGrams: number; mrp: number; price: number; stock: number; sku: string }>;
  nutrition: Record<string, string>;
};

const photos = {
  almonds: "https://images.pexels.com/photos/5959628/pexels-photo-5959628.jpeg?auto=compress&cs=tinysrgb&w=1000",
  nuts: "https://images.pexels.com/photos/5202285/pexels-photo-5202285.jpeg?auto=compress&cs=tinysrgb&w=1000",
  mixed: "https://images.pexels.com/photos/11505597/pexels-photo-11505597.jpeg?auto=compress&cs=tinysrgb&w=1000",
  dates: "https://images.pexels.com/photos/30709483/pexels-photo-30709483.jpeg?auto=compress&cs=tinysrgb&w=1000",
  seeds: "https://images.pexels.com/photos/971080/pexels-photo-971080.jpeg?auto=compress&cs=tinysrgb&w=1000",
  spices: "https://images.pexels.com/photos/7829483/pexels-photo-7829483.jpeg?auto=compress&cs=tinysrgb&w=1000",
  herbs: "https://images.pexels.com/photos/7283473/pexels-photo-7283473.jpeg?auto=compress&cs=tinysrgb&w=1000",
  grocery: "https://images.pexels.com/photos/7090155/pexels-photo-7090155.jpeg?auto=compress&cs=tinysrgb&w=1000",
};

export const heroImages = {
  main: "https://images.pexels.com/photos/35339669/pexels-photo-35339669.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=1800",
  dates: "https://images.pexels.com/photos/30709483/pexels-photo-30709483.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=1800",
  spices: "https://images.pexels.com/photos/7829483/pexels-photo-7829483.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=1800",
};

export const demoCategories: DemoCategory[] = [
  { name: "Dry Fruits", slug: "dry-fruits", description: "Wholesome nuts, carefully selected for everyday goodness.", image: photos.nuts },
  { name: "Dates", slug: "dates", description: "Naturally sweet, soft dates in premium varieties.", image: photos.dates },
  { name: "Seeds", slug: "seeds", description: "Nutrient-rich seeds for balanced modern lifestyles.", image: photos.seeds },
  { name: "Spices & Masala", slug: "spices-masala", description: "Pure spices and aromatic blends for Indian kitchens.", image: photos.spices },
  { name: "Grocery", slug: "grocery", description: "Dependable everyday staples, hygienically packed.", image: photos.grocery },
];

const lists: Record<string, string[]> = {
  "dry-fruits": ["California Almonds", "Whole Cashews", "Roasted Pistachios", "Premium Walnuts", "Seedless Raisins", "Dried Figs", "Himalayan Makhana"],
  dates: ["Zahidi Dates", "Medjool Dates"],
  seeds: ["Chia Seeds", "Pumpkin Seeds", "Sunflower Seeds", "Flax Seeds", "Five Seed Mix"],
  "spices-masala": ["Turmeric Powder", "Red Chilli Powder", "Coriander Powder", "Garam Masala", "Sabji Masala", "Chaat Masala", "Tandoori Masala", "Black Pepper"],
  grocery: ["Thick Poha", "Macaroni", "Durum Wheat Pasta", "Suji", "Daliya", "Maida", "Rolled Oats", "Crystal Sugar", "Chana Dal", "Moong Dal", "Masoor Dal", "Urad Dal", "Arhar Dal", "Rajma", "Soybean"],
};

const categoryPhoto: Record<string, string> = {
  "dry-fruits": photos.nuts,
  dates: photos.dates,
  seeds: photos.seeds,
  "spices-masala": photos.spices,
  grocery: photos.grocery,
};

function slugify(value: string) {
  return value.toLowerCase().replace(/&/g, "and").replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
}

function sizesFor(category: string) {
  if (category === "spices-masala") return [[100, "100g"], [200, "200g"], [500, "500g"]] as const;
  if (category === "seeds") return [[200, "200g"], [500, "500g"], [1000, "1kg"]] as const;
  if (category === "grocery") return [[500, "500g"], [1000, "1kg"]] as const;
  return [[250, "250g"], [500, "500g"], [1000, "1kg"]] as const;
}

const categoryNameMap = Object.fromEntries(demoCategories.map((category) => [category.slug, category.name]));

let productCounter = 1;
export const demoProducts: DemoProduct[] = Object.entries(lists).flatMap(([category, names]) =>
  names.map((name, categoryIndex) => {
    const id = productCounter++;
    const base = category === "dry-fruits" || category === "dates" ? 229 + categoryIndex * 34 : category === "spices-masala" ? 69 + categoryIndex * 12 : 89 + categoryIndex * 15;
    const sizes = sizesFor(category);
    const variants = sizes.map(([grams, label], variantIndex) => {
      const factor = grams / sizes[0][0];
      const price = Math.round((base * factor * (1 - variantIndex * 0.08)) / 5) * 5;
      return {
        id: id * 10 + variantIndex + 1,
        label,
        weightGrams: grams,
        mrp: Math.ceil((price * 1.18) / 5) * 5,
        price,
        stock: 28 + ((id + variantIndex) % 6) * 11,
        sku: `NWT-${category.slice(0, 3).toUpperCase()}-${String(id).padStart(3, "0")}-${grams}`,
      };
    });
    const first = variants[0];
    const image = name.includes("Almond") ? photos.almonds : name.includes("Mix") ? photos.mixed : categoryPhoto[category];
    return {
      id,
      name,
      slug: slugify(name),
      category,
      categoryName: categoryNameMap[category],
      shortDescription: `Premium ${name.toLowerCase()}, hygienically packed for lasting freshness.`,
      description: `NEWTAS ${name} is selected with care and packed in a hygienic environment. A dependable pantry choice created for freshness, convenience and everyday Indian households. This is sample catalog information and can be edited from the admin panel.`,
      ingredients: name,
      image,
      images: [image, categoryPhoto[category], category === "spices-masala" ? photos.herbs : photos.mixed],
      mrp: first.mrp,
      price: first.price,
      rating: Number((4.2 + (id % 7) * 0.1).toFixed(1)),
      reviewCount: 0,
      pack: first.label,
      stock: first.stock,
      sku: first.sku,
      hsn: "Editable in admin",
      gstPercent: 5,
      featured: id % 3 === 0 || id <= 4,
      bestSeller: id % 5 === 1 || id === 2,
      isNew: id % 6 === 0,
      variants,
      nutrition: { Energy: "To be updated", Protein: "To be updated", Carbohydrate: "To be updated", Fat: "To be updated" },
    };
  }),
);

export const company = {
  name: "NEWTAS FOODS AND AGRO PRIVATE LIMITED",
  brand: "NEWTAS",
  email: "newtasfoodsandagro@gmail.com",
  address: "Shastri Colony, Behind New Mandi, Etawah, Uttar Pradesh, India",
  gstin: "09AALCN8019Q1ZK",
  directors: [
    { name: "Anurudh Yadav", phone: "7726939092" },
    { name: "Eshu Goyal", phone: "7906275204" },
  ],
};

export const policyContent: Record<string, { title: string; eyebrow: string; intro: string; sections: Array<{ title: string; body: string }> }> = {
  "privacy-policy": {
    title: "Privacy Policy",
    eyebrow: "Your privacy matters",
    intro: "This policy explains how NEWTAS may collect, use and safeguard customer information when the online store launches.",
    sections: [
      { title: "Information we collect", body: "Account, address, order and support information needed to fulfil purchases and improve service. Payment credentials are handled by the selected compliant payment gateway and are not stored by NEWTAS." },
      { title: "How information is used", body: "To process orders, provide updates, prevent fraud, respond to requests and meet legal obligations. Marketing communication is sent only where permitted." },
      { title: "Your choices", body: "You may request profile corrections, communication preferences or account support by contacting the company email shown on this website." },
    ],
  },
  "terms-conditions": {
    title: "Terms & Conditions",
    eyebrow: "Store terms",
    intro: "These editable launch terms govern access to the NEWTAS online store and purchase of packaged food products.",
    sections: [
      { title: "Catalog and pricing", body: "Sample products and prices are demonstrative until approved in the admin panel. Confirmed order pricing, taxes and availability are displayed before payment." },
      { title: "Orders", body: "Orders may be declined or cancelled for stock, serviceability, payment validation or legal reasons. Customers will be notified through registered contact details." },
      { title: "Responsible use", body: "Users must provide accurate details and must not misuse accounts, promotions, reviews or technical services." },
    ],
  },
  "shipping-policy": {
    title: "Shipping Policy",
    eyebrow: "Delivery information",
    intro: "Delivery estimates, charges and pincode serviceability are shown at checkout before an order is placed.",
    sections: [
      { title: "Dispatch", body: "Orders are prepared only after stock and payment verification. Dispatch timelines may vary by destination, public holidays and courier operations." },
      { title: "Charges", body: "A standard delivery charge may apply below the free-delivery threshold. Current fees and thresholds remain editable by an administrator." },
      { title: "Tracking", body: "When a courier accepts the shipment, tracking details can be viewed through My Orders or the Track Order page." },
    ],
  },
  "return-refund-policy": {
    title: "Return & Refund Policy",
    eyebrow: "Purchase support",
    intro: "Food safety matters. Eligible concerns should be reported promptly with order details and clear supporting photographs.",
    sections: [
      { title: "Eligible concerns", body: "Incorrect, damaged, tampered or expired products may be reviewed for replacement or refund according to applicable law and final approved store policy." },
      { title: "Non-returnable items", body: "Opened or consumed food products ordinarily cannot be returned unless the concern relates to verified quality, damage or legal rights." },
      { title: "Refund processing", body: "Approved refunds are issued to the original payment method where possible. Banking timelines are controlled by the payment provider." },
    ],
  },
  "cookie-policy": {
    title: "Cookie Policy",
    eyebrow: "Site preferences",
    intro: "Essential browser storage supports cart continuity, secure sessions and basic site functionality.",
    sections: [
      { title: "Essential storage", body: "The website uses essential cookies or local storage for sessions, cart and wishlist features. Optional analytics should be enabled only with an appropriate consent mechanism." },
    ],
  },
};
