import "server-only";

import { db } from "@/db";
import { sessions, users } from "@/db/schema";
import { and, eq, gt } from "drizzle-orm";
import { cookies } from "next/headers";
import { randomBytes } from "node:crypto";

const COOKIE_NAME = "newtas_session";
const SESSION_DAYS = 14;

export async function createSession(userId: number) {
  const id = randomBytes(32).toString("base64url");
  const expiresAt = new Date(Date.now() + SESSION_DAYS * 24 * 60 * 60 * 1000);
  await db.insert(sessions).values({ id, userId, expiresAt });
  const store = await cookies();
  store.set(COOKIE_NAME, id, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    expires: expiresAt,
  });
  return id;
}

export async function deleteSession() {
  const store = await cookies();
  const id = store.get(COOKIE_NAME)?.value;
  if (id) await db.delete(sessions).where(eq(sessions.id, id));
  store.delete(COOKIE_NAME);
}

export async function getCurrentUser() {
  try {
    const id = (await cookies()).get(COOKIE_NAME)?.value;
    if (!id) return null;
    const [row] = await db
      .select({ id: users.id, name: users.name, email: users.email, mobile: users.mobile, role: users.role, isActive: users.isActive })
      .from(sessions)
      .innerJoin(users, eq(sessions.userId, users.id))
      .where(and(eq(sessions.id, id), gt(sessions.expiresAt, new Date()), eq(users.isActive, true)))
      .limit(1);
    return row ?? null;
  } catch {
    return null;
  }
}

export async function requireUser() {
  const user = await getCurrentUser();
  if (!user) throw new Error("UNAUTHORIZED");
  return user;
}

export async function requireAdmin() {
  const user = await requireUser();
  if (user.role !== "admin") throw new Error("FORBIDDEN");
  return user;
}
